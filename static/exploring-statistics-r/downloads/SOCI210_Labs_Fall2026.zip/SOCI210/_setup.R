# Exploring Statistics with R
# Shared setup used by the chapter scripts

required_packages <- c("tidyverse", "PMCMRplus")

for (package in required_packages) {
  if (!requireNamespace(package, quietly = TRUE)) {
    install.packages(package, repos = "https://cloud.r-project.org")
  }
}

suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(PMCMRplus))

theme_set(theme_minimal(base_size = 12))

cohens_d <- function(mean_difference, standard_deviation) {
  mean_difference / standard_deviation
}

statistical_mode <- function(x, na.rm = TRUE) {
  if (na.rm) {
    x <- x[!is.na(x)]
  }

  frequencies <- table(x)
  modes <- names(frequencies)[frequencies == max(frequencies)]
  type.convert(modes, as.is = TRUE)
}

sample_skewness <- function(x, na.rm = TRUE) {
  if (na.rm) {
    x <- x[!is.na(x)]
  }

  sum((x - mean(x))^3) /
    ((length(x) - 1) * sd(x)^3)
}

independent_cohens_d <- function(data, outcome, group) {
  group_stats <- data |>
    drop_na({{ outcome }}, {{ group }}) |>
    group_by({{ group }}) |>
    summarise(
      N = n(),
      Mean = mean({{ outcome }}),
      SD = sd({{ outcome }}),
      .groups = "drop"
    )

  pooled_sd <- sqrt(
    ((group_stats$N[1] - 1) * group_stats$SD[1]^2 +
      (group_stats$N[2] - 1) * group_stats$SD[2]^2) /
      (group_stats$N[1] + group_stats$N[2] - 2)
  )

  tibble(
    MeanDifference = group_stats$Mean[1] - group_stats$Mean[2],
    PooledSD = pooled_sd,
    CohensD = cohens_d(MeanDifference, PooledSD)
  )
}

anova_eta_squared <- function(anova_model, group_name) {
  anova_table <- summary(anova_model)[[1]]
  anova_table[group_name, "Sum Sq"] / sum(anova_table[, "Sum Sq"])
}

repeated_eta_squared <- function(anova_model, condition_name) {
  anova_table <- summary(anova_model)[[1]]
  anova_table[condition_name, "Sum Sq"] /
    (anova_table[condition_name, "Sum Sq"] + anova_table["Residuals", "Sum Sq"])
}

repeated_pairwise_tests <- function(
  data,
  outcome,
  condition,
  participant,
  anova_model = NULL
) {
  outcome_name <- rlang::as_name(rlang::enquo(outcome))
  condition_name <- rlang::as_name(rlang::enquo(condition))
  participant_name <- rlang::as_name(rlang::enquo(participant))
  condition_levels <- levels(data[[condition_name]])
  comparisons <- combn(condition_levels, 2, simplify = FALSE)

  if (is.null(anova_model)) {
    model_formula <- reformulate(
      c(condition_name, paste0("factor(", participant_name, ")")),
      response = outcome_name
    )
    anova_model <- aov(model_formula, data = data)
  }

  model <- anova_model
  residual_sd <- sqrt(summary(model)[[1]]["Residuals", "Mean Sq"])

  purrr::map_dfr(comparisons, function(comparison) {
    paired_data <- data |>
      filter(.data[[condition_name]] %in% comparison) |>
      select(
        all_of(participant_name),
        all_of(condition_name),
        all_of(outcome_name)
      ) |>
      pivot_wider(
        names_from = all_of(condition_name),
        values_from = all_of(outcome_name)
      )

    difference <- paired_data[[comparison[1]]] -
      paired_data[[comparison[2]]]
    test <- t.test(difference, mu = 0)
    tukey_p <- ptukey(
      abs(unname(test$statistic)) * sqrt(2),
      nmeans = length(condition_levels),
      df = unname(test$parameter),
      lower.tail = FALSE
    )

    tibble(
      Comparison = paste(comparison, collapse = " - "),
      MeanDifference = mean(difference),
      p = tukey_p,
      CohensD = abs(mean(difference) / residual_sd)
    )
  })
}

two_way_anova_table <- function(anova_model) {
  anova_drop <- drop1(
    anova_model,
    scope = attr(terms(anova_model), "term.labels"),
    test = "F"
  )
  residual_ss <- anova_drop["<none>", "RSS"]

  anova_drop |>
    as.data.frame() |>
    rownames_to_column("Effect") |>
    filter(Effect != "<none>") |>
    transmute(
      Effect = Effect,
      Df = Df,
      SumOfSquares = `Sum of Sq`,
      F = `F value`,
      p = `Pr(>F)`,
      PartialEtaSquared = SumOfSquares / (SumOfSquares + residual_ss)
    )
}

cramers_v <- function(chi_square_test) {
  observed <- chi_square_test$observed
  sqrt(
    as.numeric(chi_square_test$statistic) /
      (sum(observed) * (min(dim(observed)) - 1))
  )
}

rank_biserial_independent <- function(test_object, group) {
  group <- droplevels(factor(group[!is.na(group)]))
  group_sizes <- table(group)

  if (length(group_sizes) != 2) {
    stop("The grouping variable must contain exactly two groups.")
  }

  abs(
    2 * as.numeric(test_object$statistic) / prod(group_sizes) - 1
  )
}

rank_biserial_paired <- function(x, y) {
  complete <- complete.cases(x, y)
  differences <- x[complete] - y[complete]
  differences <- differences[differences != 0]
  difference_ranks <- rank(abs(differences))
  positive_ranks <- sum(difference_ranks[differences > 0])
  negative_ranks <- sum(difference_ranks[differences < 0])

  abs(
    (positive_ranks - negative_ranks) /
      (positive_ranks + negative_ranks)
  )
}

kruskal_epsilon_squared <- function(test_object, group) {
  group <- droplevels(factor(group[!is.na(group)]))
  sample_size <- length(group)
  group_count <- nlevels(group)

  max(
    0,
    (
      as.numeric(test_object$statistic) - group_count + 1
    ) / (sample_size - group_count)
  )
}

tukey_cohens_d <- function(anova_model, tukey_output, group_name) {
  anova_table <- summary(anova_model)[[1]]
  residual_sd <- sqrt(anova_table["Residuals", "Mean Sq"])

  tibble(
    Comparison = rownames(tukey_output[[group_name]]),
    CohensD = cohens_d(
      abs(tukey_output[[group_name]][, "diff"]),
      residual_sd
    )
  )
}
