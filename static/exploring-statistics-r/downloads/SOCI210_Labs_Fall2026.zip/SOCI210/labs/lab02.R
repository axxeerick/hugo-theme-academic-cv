# ============================================================
# Lab 2: Comparing Scores and Identifying Unusual Cases
# ============================================================

source("_setup.R")

famelo <- readRDS("data/famelo_soci210_students.rds")

# Purpose: Use Chapter 5 tools to interpret z scores, compare distributions
# with boxplots, identify unusual cases, and interpret an effect size.

# ------------------------------------------------------------
# 1. Comparing scores with z scores
# ------------------------------------------------------------

# The variable household_assets is standardized separately within each
# country. Student A has a score of 1.25; Student B has a score of -0.75.

# a. Explain what each score says about that household relative to other
# households in the same country.
# ANSWER:

# b. Which young person lives in the relatively more advantaged household?
# ANSWER:

# c. If they live in different countries, why do these scores not establish
# that Student A's household has more assets in absolute terms?
# ANSWER:

# ------------------------------------------------------------
# 2. Examining distributions with boxplots
# ------------------------------------------------------------

# Adapt Chapter 5 code to create boxplots of desired_marriage_age separately
# by sex. Give the graph appropriate labels.
# YOUR CODE:

# In 2-3 sentences, compare centers, variability, and potential outliers.
# ANSWER:

# ------------------------------------------------------------
# 3. Quantifying a group difference
# ------------------------------------------------------------

# Adapt the workbook code to calculate the appropriate effect size for the
# difference in desired_marriage_age between the two sex groups.
# YOUR CODE:

# a. Report the effect size.
# ANSWER:

# b. In 1-2 sentences, interpret its size and direction. Do not interpret
# statistical significance.
# ANSWER:

# ------------------------------------------------------------
# 4. Put the evidence together
# ------------------------------------------------------------

# Do young women and young men in FAMELO differ in when they would like to
# marry? Write a 3-5 sentence descriptive report using the graph and
# numerical results. Do not make causal or population-level claims.
# ANSWER:

# ------------------------------------------------------------
# What to submit
# ------------------------------------------------------------

# Submit this completed R script through Microsoft Teams. Before submitting,
# run the whole script and check the code, labels, graph, output, and responses.
