# ============================================================
# Lab 5: Evaluating Statistical Evidence
# ============================================================

source("_setup.R")

famelo <- readRDS("data/famelo_soci210_students.rds")

# Purpose: Use Chapters 9-10 to combine descriptive evidence, a hypothesis
# test, an effect size, and a confidence interval.

# ------------------------------------------------------------
# 1. A research question
# ------------------------------------------------------------

# Do young women and young men in FAMELO differ in the age at which they
# would like to marry? Use sex and desired_marriage_age.

# a. State the null hypothesis in words.
# ANSWER:

# b. State an appropriate alternative hypothesis in words.
# ANSWER:

# c. Is this a paired-samples or independent-samples design? Explain.
# ANSWER:

# ------------------------------------------------------------
# 2. Examine the evidence
# ------------------------------------------------------------

# Create an appropriate graph and descriptive statistics comparing
# desired_marriage_age by sex. Then conduct the appropriate two-sample test.
# YOUR CODE:

# Report the p-value.
# ANSWER:

# Using alpha = .05, what decision do you make about the null hypothesis?
# Explain the result in the context of the research question.
# ANSWER:

# ------------------------------------------------------------
# 3. Statistical significance is not the whole story
# ------------------------------------------------------------

# Calculate the effect size and obtain the confidence interval for the
# difference between groups using workbook techniques.
# YOUR CODE:

# In 2-3 sentences, combine the observed difference, effect size, confidence
# interval, and hypothesis-test result.
# ANSWER:

# ------------------------------------------------------------
# 4. Interpret the analysis carefully
# ------------------------------------------------------------

# Choose one statement, explain why it is inappropriate, and replace it with
# a defensible conclusion.
# A. "Because p < .05, there is a 95% probability that the alternative
#    hypothesis is true."
# B. "Because the result is statistically significant, the difference must
#    be large and important."
# C. "Sex causes young people to differ in desired marriage age."
# ANSWER:

# ------------------------------------------------------------
# What to submit
# ------------------------------------------------------------

# Submit this completed R script through Microsoft Teams. Before submitting,
# run the whole script and check the graph, output, and responses.
