# ============================================================
# Lab 3: Relationships in Social Data
# ============================================================

source("_setup.R")

famelo <- readRDS("data/famelo_soci210_students.rds")

# Purpose: Use Chapter 6 tools to investigate relationships with
# scatterplots, correlation, regression, and prediction while separating
# association from causation.

# ------------------------------------------------------------
# 1. Visualizing a relationship
# ------------------------------------------------------------

# Create a scatterplot of age and desired_marriage_age. Include a regression
# line as demonstrated in the workbook and give the graph appropriate labels.
# YOUR CODE:

# In 2-3 sentences, describe direction, strength, and overall pattern.
# ANSWER:

# ------------------------------------------------------------
# 2. Measuring the relationship
# ------------------------------------------------------------

# Calculate Pearson's r for age and desired_marriage_age.
# YOUR CODE:

# a. Report the correlation.
# ANSWER:

# b. In 1-2 sentences, interpret its direction and strength.
# ANSWER:

# c. Calculate the proportion of common variance and explain its meaning.
# YOUR CODE:
# ANSWER:

# ------------------------------------------------------------
# 3. Regression and prediction
# ------------------------------------------------------------

# Estimate a regression model predicting desired_marriage_age from age.
# YOUR CODE:

# a. Report and interpret the slope in context.
# ANSWER:

# b. Use the regression equation to predict desired marriage age for a
# respondent who is 18 years old.
# YOUR CODE:
# ANSWER:

# ------------------------------------------------------------
# 4. What can we conclude?
# ------------------------------------------------------------

# Explain why this claim is not justified: "Getting older causes young people
# to want to marry at an older age."
# ANSWER:

# Write a better 2-3 sentence conclusion about what these data allow us to say.
# ANSWER:

# ------------------------------------------------------------
# What to submit
# ------------------------------------------------------------

# Submit this completed R script through Microsoft Teams. Before submitting,
# run the whole script and check the graph, output, calculations, and responses.
