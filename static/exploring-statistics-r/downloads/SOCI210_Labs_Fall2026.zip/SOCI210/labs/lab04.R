# ============================================================
# Lab 4: From Samples to Populations
# ============================================================

source("_setup.R")

famelo <- readRDS("data/famelo_soci210_students.rds")

# Purpose: Use Chapters 7-8 and a simulation to examine random sampling,
# sampling distributions, the Central Limit Theorem, standard error, and
# precision.
#
# SUPPLIED CODE in this lab introduces sampling commands that the workbook
# does not teach. Run and interpret it; you are not expected to memorize it.

# ------------------------------------------------------------
# 1. From a population to a sample
# ------------------------------------------------------------

# SUPPLIED CODE: Create the population for this exercise.
mexico <- famelo %>%
  filter(
    country == "Mexico",
    !is.na(desired_marriage_age)
  )

# Calculate the population mean and create a histogram of the population.
# YOUR CODE:

# In 1-2 sentences, describe the population distribution and report its mean.
# ANSWER:

# SUPPLIED CODE: Draw a random sample of 30 respondents.
set.seed(210)
sample_30 <- mexico %>%
  slice_sample(n = 30)

# Calculate the mean desired_marriage_age in sample_30.
# YOUR CODE:

# Is the sample mean exactly equal to the population mean? Why should we not
# necessarily expect it to be?
# ANSWER:

# ------------------------------------------------------------
# 2. What happens if we take many samples?
# ------------------------------------------------------------

# SUPPLIED CODE: Draw 1,000 samples of 30 and save each sample mean.
set.seed(210)
sample_means_30 <- replicate(
  1000,
  mexico %>%
    slice_sample(n = 30) %>%
    summarise(
      sample_mean = mean(desired_marriage_age)
    ) %>%
    pull(sample_mean)
)

sample_means_30 <- tibble(
  sample_mean = sample_means_30
)

# Create a histogram of sample_mean.
# YOUR CODE:

# Compare this graph with the population distribution. What does the new
# distribution represent, and how does it differ from the distribution of
# individual scores? Use the term sampling distribution.
# ANSWER:

# ------------------------------------------------------------
# 3. Why does sample size matter?
# ------------------------------------------------------------

# SUPPLIED CODE: Draw 1,000 samples of 100 and save each sample mean.
set.seed(210)
sample_means_100 <- replicate(
  1000,
  mexico %>%
    slice_sample(n = 100) %>%
    summarise(
      sample_mean = mean(desired_marriage_age)
    ) %>%
    pull(sample_mean)
)

sample_means_100 <- tibble(
  sample_mean = sample_means_100
)

# Graph this sampling distribution. Calculate the standard deviation of the
# sample means for sample_means_30 and sample_means_100.
# YOUR CODE:

# Compare the two sampling distributions. What happened to variability when
# n increased from 30 to 100? Explain why this matters, using standard error.
# ANSWER:

# ------------------------------------------------------------
# 4. Connect the simulation to statistical theory
# ------------------------------------------------------------

# a. Distinguish a population distribution, a sample distribution, and a
# sampling distribution.
# ANSWER:

# b. Under the Central Limit Theorem, what should happen to the sampling
# distribution of the mean as sample size becomes larger?
# ANSWER:

# c. All else equal, would a random sample of 30 or 500 give the more precise
# estimate of the same population mean? Why?
# ANSWER:

# ------------------------------------------------------------
# What to submit
# ------------------------------------------------------------

# Submit this completed R script through Microsoft Teams. Before submitting,
# run the whole script and check the graphs, output, and responses.
