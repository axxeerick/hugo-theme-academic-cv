# ============================================================
# Lab 1: Describing the Transition to Adulthood
# ============================================================

source("_setup.R")

famelo <- readRDS("data/famelo_soci210_students.rds")

# Purpose: Practice describing variables and distributions, choosing
# appropriate summaries and graphs, comparing groups, and interpreting
# statistical results in context.
# Use the course workbook as needed. Find examples and adapt them rather
# than trying to write R code from memory.

# ------------------------------------------------------------
# 1. Understanding the data
# ------------------------------------------------------------

# This lab uses country, age, sex, enrolled_school, paid_work, and
# subjective_adulthood.

# a. What does one row of the FAMELO dataframe represent?
# ANSWER:

# b. Classify country, age, sex, and enrolled_school as quantitative or
# categorical variables.
# ANSWER:

# ------------------------------------------------------------
# 2. How old are the young people in FAMELO?
# ------------------------------------------------------------

# Adapt workbook code to create an appropriate graph of age and calculate
# the mean and median. Make sure the graph has appropriate labels.
# YOUR CODE:

# In 2-3 sentences, describe the age distribution. Use both the graph and
# the measures of central tendency as evidence.
# ANSWER:

# ------------------------------------------------------------
# 3. Does the age distribution differ across countries?
# ------------------------------------------------------------

# Adapt workbook code to compare age across Mexico, Mozambique, and Nepal.
# Include an appropriate visualization and measure of central tendency for
# each country.
# YOUR CODE:

# In 2-3 sentences, describe the most important similarity or difference.
# ANSWER:

# ------------------------------------------------------------
# 4. Your turn: another part of the transition to adulthood
# ------------------------------------------------------------

# Choose one: enrolled_school, paid_work, or subjective_adulthood.
# These variables are categorical, so do not repeat the analysis for age.
# Create one appropriate numerical or tabular summary and one graph.
# YOUR CODE:

# In 2-3 sentences, explain what the results tell us about the young people
# in FAMELO.
# ANSWER:

# In one sentence, explain why your summary and graph are appropriate for
# this type of variable.
# ANSWER:

# ------------------------------------------------------------
# What to submit
# ------------------------------------------------------------

# Submit this completed R script through Microsoft Teams. Before submitting,
# run the whole script and check the code, labels, graphs, and responses.
