# ============================================================
# Lab 6: Comparing Multiple Groups
# ============================================================

source("_setup.R")

famelo <- readRDS("data/famelo_soci210_students.rds")

# Purpose: Use Chapter 11 to compare mean desired marriage age across the
# three FAMELO countries with ANOVA, effect size, and pairwise comparisons.
# Use the workbook to identify and adapt the appropriate code.

# ------------------------------------------------------------
# 1. Comparing three countries
# ------------------------------------------------------------

# Does desired marriage age differ among young people in Mexico, Mozambique,
# and Nepal? Use country and desired_marriage_age.

# a. Identify the independent and dependent variables.
# ANSWER:

# b. State the null hypothesis in words.
# ANSWER:

# c. Why is ANOVA more appropriate than a series of independent-samples
# t tests?
# ANSWER:

# ------------------------------------------------------------
# 2. Examine the distributions
# ------------------------------------------------------------

# Create an appropriate graph and descriptive statistics comparing the
# distributions across countries.
# YOUR CODE:

# In 2-3 sentences, describe the centers and variability you observe.
# ANSWER:

# ------------------------------------------------------------
# 3. Conduct the ANOVA
# ------------------------------------------------------------

# Conduct a one-way ANOVA of desired_marriage_age by country. Report the F
# statistic and p-value, then calculate the appropriate effect size.
# YOUR CODE:

# In 2-3 sentences, distinguish statistical evidence that the means differ
# from how much variation in desired marriage age is associated with country.
# ANSWER:

# ------------------------------------------------------------
# 4. Where are the differences?
# ------------------------------------------------------------

# If the ANOVA provides evidence of a difference, conduct the appropriate
# post hoc pairwise comparisons.
# YOUR CODE:

# Which comparisons provide evidence of mean differences? Write a 3-4
# sentence conclusion combining descriptives, ANOVA, effect size, and post
# hoc comparisons. Describe the substantive pattern.
# ANSWER:

# ------------------------------------------------------------
# 5. Choosing the right procedure
# ------------------------------------------------------------

# Would this ANOVA be appropriate for comparing enrolled_school across the
# three countries? Answer yes or no and explain. No analysis is required.
# ANSWER:

# ------------------------------------------------------------
# What to submit
# ------------------------------------------------------------

# Submit this completed R script through Microsoft Teams. Before submitting,
# run the whole script and check the graph, output, and responses.
