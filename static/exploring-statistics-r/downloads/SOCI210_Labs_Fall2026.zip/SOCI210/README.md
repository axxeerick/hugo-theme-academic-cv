# SOCI 210: Social Statistics Labs

1. Open `SOCI210.Rproj` in RStudio before working on a lab. Always open the project first so the lab can find its files.
2. The FAMELO course dataset is in `data/`, and the six lab scripts are in `labs/`. Supporting codebooks are in `data/codebooks/`.
3. Open the assigned `.R` file and put R commands below `# YOUR CODE:`. Type written responses after `# ANSWER:` as comments beginning with `#`.
4. Use the [*Exploring Statistics with R* workbook](https://axxe.netlify.app/exploring-statistics-r/) and its [R command index](https://axxe.netlify.app/exploring-statistics-r/reference/r-command-index) to find an appropriate example and adapt it. You are not expected to memorize R syntax.
5. `_setup.R` contains packages and functions used by the course workbook and labs. You generally do not need to edit it; each lab loads it automatically with `source("_setup.R")`.
6. Before submitting, restart R and run the entire script from beginning to end using **Source**. Fix any errors and confirm that all requested graphs appear.
7. Submit your completed `.R` file through Microsoft Teams.
