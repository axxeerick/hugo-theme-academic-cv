Exploring Statistics with R - Starter Files

1. Open RStudio.
2. Choose File > Open Project...
3. Select exploring-statistics-r.Rproj from this folder.
4. In the Files pane, open scripts/00-open-and-check-data.R.
5. Click Source to run the whole script.

The script should create an object named eammi and print:
- 2073 rows
- 39 columns
- a list of variable names
- a small frequency table for Gender

The first run may take a few minutes because the setup file checks for
the R tools used in the scripts and installs them if needed.

After the starter script works, open scripts/01-introduction.R for the
Chapter 1 code.

The resources folder includes EAMMI2_Survey_withcodes.pdf, which shows
the original survey questions and response codes.
