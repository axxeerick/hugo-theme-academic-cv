# Exploring Statistics with R: Chapter 13: Two-Way Independent Analysis of Variance
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# Give Adult and PoliticsDichotomous readable factor labels.

eammi <- eammi |>
  mutate(
    PoliticsDichotomous = factor(
      PoliticsDichotomous,
      levels = c(1, 2),
      labels = c("Liberal", "Conservative")
    ),
    Adult = factor(
      Adult,
      levels = c(3, 2, 1),
      labels = c("No", "Maybe", "Yes")
    )
  )

swls_data <- eammi |>
  drop_na(SWLS, PoliticsDichotomous, Adult)

# ---- Run The Model ----

# Fit the two-way ANOVA model with both main effects and their interaction.

swls_anova <- aov(
  SWLS ~ PoliticsDichotomous * Adult,
  data = swls_data,
  contrasts = list(
    PoliticsDichotomous = contr.sum,
    Adult = contr.sum
  )
)

# ---- Check The Assumptions ----

# Test whether the six groups have similar variances.

bartlett.test(
  SWLS ~ interaction(PoliticsDichotomous, Adult),
  data = swls_data
)

# Test whether the ANOVA residuals are normally distributed.

shapiro.test(residuals(swls_anova))

# ---- Run The Analysis ----

# Summarize satisfaction with life for every combination of the two factors.

swls_cell_summary <- swls_data |>
  group_by(Adult, PoliticsDichotomous) |>
  summarise(
    N = n(),
    Mean = mean(SWLS),
    SD = sd(SWLS),
    SE = SD / sqrt(N),
    .groups = "drop"
  )

swls_cell_summary

# Use the setup file's two_way_anova_table() helper to display all three tests.

swls_anova_table <- two_way_anova_table(swls_anova)
swls_anova_table

# ---- Inspect And Interpret ----

# Follow the significant adult-status effect with adjusted pairwise comparisons.

swls_adult_tukey <- TukeyHSD(swls_anova, "Adult")
swls_adult_tukey

# Use the setup file's tukey_cohens_d() helper for each adult-status comparison.

swls_adult_pairwise_d <- tukey_cohens_d(
  swls_anova,
  swls_adult_tukey,
  "Adult"
)
swls_adult_pairwise_d

# Figure: Mean satisfaction with life by political views and adult status.

swls_cell_summary |>
  ggplot(aes(
    x = Adult,
    y = Mean,
    group = PoliticsDichotomous,
    color = PoliticsDichotomous,
    linetype = PoliticsDichotomous,
    shape = PoliticsDichotomous
  )) +
  geom_point() +
  geom_line() +
  labs(
    x = "Adult status",
    y = "Mean satisfaction with life",
    color = "Political views",
    linetype = "Political views",
    shape = "Political views"
  )

# ---- Research Question 2 ----

# Check Your Work: complete the social-support two-way ANOVA.

social_support_data <- eammi |>
  drop_na(SocialSupport, PoliticsDichotomous, Adult)

bartlett.test(
  SocialSupport ~ interaction(PoliticsDichotomous, Adult),
  data = social_support_data
)

social_support_anova <- aov(
  SocialSupport ~ PoliticsDichotomous * Adult,
  data = social_support_data,
  contrasts = list(
    PoliticsDichotomous = contr.sum,
    Adult = contr.sum
  )
)

shapiro.test(residuals(social_support_anova))

social_support_cell_summary <- social_support_data |>
  group_by(Adult, PoliticsDichotomous) |>
  summarise(
    N = n(), Mean = mean(SocialSupport), SD = sd(SocialSupport),
    SE = SD / sqrt(N), .groups = "drop"
  )

social_support_anova_table <- two_way_anova_table(social_support_anova)
social_support_cell_summary
social_support_anova_table

# Figure: Mean social support by political views and adult status.

social_support_cell_summary |>
  ggplot(aes(
    x = Adult,
    y = Mean,
    group = PoliticsDichotomous,
    color = PoliticsDichotomous,
    linetype = PoliticsDichotomous,
    shape = PoliticsDichotomous
  )) +
  geom_point() +
  geom_line() +
  labs(
    x = "Adult status",
    y = "Mean social support",
    color = "Political views",
    linetype = "Political views",
    shape = "Political views"
  )

