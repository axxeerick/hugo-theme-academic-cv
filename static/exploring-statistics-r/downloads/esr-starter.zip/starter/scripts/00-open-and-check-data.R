# Exploring Statistics with R
# Starter script: open and check the EAMMi2 data

# 0. Find the project folder.
# This makes the script more forgiving if RStudio opens in the wrong folder.
find_project_root <- function(start) {
  folder <- normalizePath(start, winslash = "/", mustWork = FALSE)

  repeat {
    project_file <- file.path(folder, "exploring-statistics-r.Rproj")
    data_file <- file.path(folder, "data", "EAMMi2-REDUCED.csv")

    if (file.exists(project_file) && file.exists(data_file)) {
      return(folder)
    }

    parent <- dirname(folder)
    if (identical(parent, folder)) {
      stop(
        "I could not find exploring-statistics-r.Rproj and data/EAMMi2-REDUCED.csv. ",
        "Open the project folder first, then run this script again.",
        call. = FALSE
      )
    }

    folder <- parent
  }
}

script_path <- ""
if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
  script_path <- rstudioapi::getSourceEditorContext()$path
}

if (!nzchar(script_path)) {
  file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  if (length(file_arg) > 0) {
    script_path <- sub("^--file=", "", file_arg[[1]])
  }
}

starting_folder <- if (nzchar(script_path)) dirname(script_path) else getwd()
project_root <- find_project_root(starting_folder)
setwd(project_root)

# 1. Install or load the needed R tools, then import the data.
source("scripts/_setup.R")

# 2. Confirm that the data imported correctly.
nrow(eammi)
ncol(eammi)
names(eammi)

# 3. Look at the data frame structure.
glimpse(eammi)

# 4. Create a small frequency table.
eammi |>
  count(Gender, name = "Frequency")
