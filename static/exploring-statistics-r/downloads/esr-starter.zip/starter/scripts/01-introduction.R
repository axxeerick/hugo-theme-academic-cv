# Exploring Statistics with R
# Chapter 1: Introduction

# Run the shared setup first. This installs or loads the needed R tools
# and creates the main data frame, eammi.
source("scripts/_setup.R")

# How many rows and columns are in the data?
dim(eammi)

# What variables are included?
names(eammi)

# Count rows and columns separately.
nrow(eammi)
ncol(eammi)

# Give the Gender variable readable category names.
eammi <- eammi |>
  mutate(
    Gender = factor(
      Gender,
      levels = c(1, 2, 3),
      labels = c("Male", "Female", "Another identity")
    )
  )

levels(eammi$Gender)

# Create a frequency table for Gender.
gender_summary <- eammi |>
  count(Gender, name = "Frequency") |>
  mutate(Percent = round(100 * Frequency / sum(Frequency), 1))

gender_summary

# Create a bar graph for Gender.
ggplot(gender_summary, aes(x = Gender, y = Frequency)) +
  geom_col() +
  labs(
    x = "Self-reported gender",
    y = "Number of participants"
  )
