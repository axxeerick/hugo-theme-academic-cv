# Exploring Statistics with R
# Shared setup used by the chapter scripts

required_packages <- c("tidyverse")

for (package in required_packages) {
  if (!requireNamespace(package, quietly = TRUE)) {
    install.packages(package, repos = "https://cloud.r-project.org")
  }
}

suppressPackageStartupMessages(library(tidyverse))

theme_set(theme_minimal(base_size = 12))

eammi <- read_csv(
  "data/EAMMi2-REDUCED.csv",
  show_col_types = FALSE
)
