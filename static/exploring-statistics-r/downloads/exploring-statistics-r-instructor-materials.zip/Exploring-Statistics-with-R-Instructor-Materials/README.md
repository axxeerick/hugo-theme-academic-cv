# Exploring Statistics with R: Instructor Materials

Prepared by Erick Axxe

This archive contains the complete *Exploring Statistics with R* publication package.

## Choose A Format

- `website/index.html` opens the rendered HTML workbook. Upload the complete `website` folder to a web host; do not upload only `index.html`.
- `pdf/Exploring-Statistics-with-R-Complete-Collection.pdf` is the complete, fixed-layout collection with a table of contents and PDF bookmarks.
- `word/` contains editable Word files for the start pages, chapters, references, and instructor guide.
- `student-starter/esr-starter.zip` is the smaller archive to distribute to students. Students should extract it and open `exploring-statistics-r.Rproj`.
- `source/` contains the Quarto source, R scripts, data, configuration, styles, filters, assets, and build tools.

## Render The Source

Install R, RStudio, Quarto, Python, and LibreOffice. Open `source/exploring-statistics-r.Rproj`, then run these commands from the `source` folder:

```bash
Rscript tools/sync-chapter-scripts.R
quarto render
python tools/render_word.py
python tools/build_combined_pdf.py
```

The first R run may install `tidyverse` and `PMCMRplus`. The Word renderer uses Python packages including `python-docx` and `lxml`; the PDF builder uses LibreOffice, `reportlab`, and `pypdf`.

## Adapt Or Distribute

Use the HTML edition for online navigation and search, the PDF for a single printable file, or individual Word chapters when local edits are needed. If a chapter analysis is changed, update the matching script and rebuild the student starter archive before distribution.

The folder structure is intentional. Keep linked files and subfolders together when copying the project to OneDrive, another computer, or a web host. OneDrive may display Word and PDF files in the browser, but Quarto source must be rendered on a computer with the required software.

If you rebuild this archive under a new name, copy the finished instructor ZIP into `website/downloads/` before publishing the website so its instructor-download link remains available.

## Data

The project uses a reduced teaching copy of the Emerging Adulthood Measured at Multiple Institutions-2 (EAMMi2) data. The [EAMMi2 project on OSF](https://osf.io/te54b/) identifies the study materials with a CC0 1.0 license.
