# Exploring Statistics with R: Chapter 10: Two-Sample Designs
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# Give the political-view codes readable group labels.

eammi <- eammi |>
  mutate(
    PoliticsDichotomous = factor(
      PoliticsDichotomous,
      levels = c(1, 2),
      labels = c("Liberal", "Conservative")
    )
  )

# ---- Run ----

# Keep complete cases and summarize belonging within each political group.

belonging_data <- eammi |>
  drop_na(PoliticsDichotomous, Belonging)

belonging_summary <- belonging_data |>
  group_by(PoliticsDichotomous) |>
  summarise(
    N = n(),
    Mean = mean(Belonging),
    Median = median(Belonging),
    SD = sd(Belonging),
    Skewness = sample_skewness(Belonging)
  )

belonging_summary

# Figure: Belonging scores for liberal and conservative participants.

belonging_data |>
  ggplot(aes(x = PoliticsDichotomous, y = Belonging)) +
  geom_boxplot() +
  labs(
    x = "Political orientation",
    y = "Belonging score"
  )

# Separate the two groups and test each belonging distribution for normality.

liberal_belonging <- belonging_data |>
  filter(PoliticsDichotomous == "Liberal") |>
  pull(Belonging)

conservative_belonging <- belonging_data |>
  filter(PoliticsDichotomous == "Conservative") |>
  pull(Belonging)

shapiro.test(liberal_belonging)
shapiro.test(conservative_belonging)

# Test whether the two political groups have similar belonging variances.

belonging_variance_test <- var.test(
  Belonging ~ PoliticsDichotomous,
  data = belonging_data
)

belonging_variance_test

# Compare mean belonging across the two independent political groups.

belonging_t_test <- t.test(
  Belonging ~ PoliticsDichotomous,
  data = belonging_data,
  var.equal = TRUE
)

belonging_t_test

# ---- Calculate Effect Size ----

# Summarize the groups, then use the setup file's independent_cohens_d() helper.

belonging_group_stats <- eammi |>
  drop_na(PoliticsDichotomous, Belonging) |>
  group_by(PoliticsDichotomous) |>
  summarise(
    N = n(),
    Mean = mean(Belonging),
    SD = sd(Belonging)
  )

belonging_d <- independent_cohens_d(
  eammi,
  Belonging,
  PoliticsDichotomous
)

belonging_group_stats
belonging_d

# ---- Run ----

# Keep complete pairs and calculate one difference score per participant.

usdream_data <- eammi |>
  drop_na(USdream1, USdream2) |>
  mutate(
    Difference = USdream1 - USdream2
  )

usdream_summary <- usdream_data |>
  summarise(
    N = n(),
    USdream1_Mean = mean(USdream1),
    USdream1_SD = sd(USdream1),
    USdream2_Mean = mean(USdream2),
    USdream2_SD = sd(USdream2),
    DifferenceSkewness = sample_skewness(Difference)
  )

usdream_summary

# Test whether the paired difference scores are normally distributed.

usdream_normality_test <- shapiro.test(usdream_data$Difference)

usdream_normality_test

# Compare the two American Dream ratings from the same participants.

usdream_t_test <- t.test(
  usdream_data$USdream1,
  usdream_data$USdream2,
  paired = TRUE
)

usdream_t_test

# ---- Calculate Effect Size ----

# Use the setup file's cohens_d() helper to standardize the mean paired difference.

usdream_difference <- usdream_data$Difference
usdream_d <- cohens_d(
  mean(usdream_difference),
  sd(usdream_difference)
)

usdream_d

# ---- Research Question 3 ----

# Check Your Work: complete the exploration-versus-identity paired analysis.

exploration_identity_data <- eammi |>
  drop_na(Exploration, Identity) |>
  mutate(
    Difference = Exploration - Identity
  )

exploration_identity_summary <- exploration_identity_data |>
  summarise(
    N = n(),
    Exploration_Mean = mean(Exploration),
    Exploration_SD = sd(Exploration),
    Identity_Mean = mean(Identity),
    Identity_SD = sd(Identity),
    DifferenceSkewness = sample_skewness(Difference)
  )

exploration_identity_normality_test <- shapiro.test(
  exploration_identity_data$Difference
)

exploration_identity_t_test <- t.test(
  exploration_identity_data$Exploration,
  exploration_identity_data$Identity,
  paired = TRUE
)

exploration_identity_difference <- exploration_identity_data$Difference
exploration_identity_d <- cohens_d(
  mean(exploration_identity_difference),
  sd(exploration_identity_difference)
)

exploration_identity_summary
exploration_identity_normality_test
exploration_identity_t_test
exploration_identity_d

