# Exploring Statistics with R: Chapter 1: Introduction
# Run one complete expression at a time as you work through the chapter.

# ---- Open the Chapter 1 script ----

source("scripts/_setup.R")

# ---- Inspect The Dataset ----

# Inspect the size of the data frame and list its variable names.

dim(eammi)
names(eammi)

# Request the number of observations and variables separately.

nrow(eammi)
ncol(eammi)

# ---- Understand Variable Types ----

# Give the numeric Gender codes readable category labels.

eammi <- eammi |>
  mutate(
    Gender = factor(
      Gender,
      levels = c(3, 2, 1),
      labels = c("Another identity", "Female", "Male")
    )
  )

levels(eammi$Gender)

# ---- Create A Frequency Table ----

# Count each gender category and calculate its percentage of the sample.

gender_summary <- eammi |>
  count(Gender, name = "Frequency") |>
  mutate(Percent = round(100 * Frequency / sum(Frequency), 1))

gender_summary

# ---- Create A Bar Chart ----

# Build a bar chart from the completed gender frequency table.

# Figure: Number of EAMMi2 participants in each self-reported gender category.

ggplot(gender_summary, aes(x = Gender, y = Frequency)) +
  geom_col() +
  labs(
    x = "Self-reported gender",
    y = "Number of participants"
  )

# ---- Exercise 2: Compare Dataset Views ----

# Compare a broad view of the data frame with a summary of one variable.

glimpse(eammi)
summary(eammi$Age)

# ---- Challenge ----

# Check Your Work: give Adult ordered labels, then count the responses.

eammi <- eammi |>
  mutate(
    Adult = factor(
      Adult,
      levels = c(3, 2, 1),
      labels = c("No", "Maybe", "Yes"),
      ordered = TRUE
    )
  )

count(eammi, Adult)

