# Exploring Statistics with R: Chapter 14: Chi-Square Tests
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# Give living-status and adult-status codes readable ordered labels.

eammi <- eammi |>
  mutate(
    NoLongerHome = factor(
      NoLongerHome,
      levels = c(1, 2, 3),
      labels = c("No", "Somewhat", "Yes")
    ),
    Adult = factor(
      Adult,
      levels = c(3, 2, 1),
      labels = c("No", "Maybe", "Yes")
    )
  )

home_adult_data <- eammi |>
  drop_na(NoLongerHome, Adult)

# ---- Run The Analysis ----

# Build the observed contingency table for living status and adult status.

home_adult_table <- table(
  home_adult_data$NoLongerHome,
  home_adult_data$Adult
)
home_adult_table

# Test whether living status and adult status are associated.

home_adult_chi <- chisq.test(home_adult_table)
home_adult_chi

# Display the expected counts used in the chi-square calculation.

home_adult_chi$expected

# Use the setup file's cramers_v() helper to measure association strength.

home_adult_v <- cramers_v(home_adult_chi)
home_adult_v

# ---- Plan And Predict ----

# Give the Gender codes readable category labels.

eammi <- eammi |>
  mutate(
    Gender = factor(
      Gender,
      levels = c(3, 2, 1),
      labels = c("Another identity", "Female", "Male")
    )
  )

gender_data <- eammi |>
  drop_na(Gender)

gender_counts <- table(gender_data$Gender)
gender_counts
prop.table(gender_counts)

# ---- Run And Investigate ----

# Compare the observed gender counts with the population proportions.

gender_chi <- chisq.test(
  gender_counts,
  p = c(.02, .51, .47)
)
gender_chi

# ---- Research Question 3 ----

# Check Your Work: test financial-independence status by adult status.

eammi <- eammi |>
  mutate(
    FinanciallyInd = factor(
      FinanciallyInd,
      levels = c(1, 2, 3),
      labels = c("No", "Somewhat", "Yes")
    )
  )

financial_adult_data <- eammi |>
  drop_na(FinanciallyInd, Adult)

financial_adult_table <- table(
  financial_adult_data$FinanciallyInd,
  financial_adult_data$Adult
)

financial_adult_chi <- chisq.test(financial_adult_table)
financial_adult_v <- cramers_v(financial_adult_chi)

financial_adult_table
financial_adult_chi
financial_adult_chi$expected
financial_adult_v

# ---- Research Question 4 ----

# Check Your Work: test party identification by political orientation.

eammi <- eammi |>
  mutate(
    PartyDichotomous = factor(
      PartyDichotomous,
      levels = c(1, 2),
      labels = c("Democrat", "Republican")
    ),
    PoliticsDichotomous = factor(
      PoliticsDichotomous,
      levels = c(1, 2),
      labels = c("Liberal", "Conservative")
    )
  )

party_data <- eammi |>
  drop_na(PartyDichotomous)

party_counts <- table(party_data$PartyDichotomous)
party_chi <- chisq.test(party_counts, p = c(.50, .50))

politics_data <- eammi |>
  drop_na(PoliticsDichotomous)

politics_counts <- table(politics_data$PoliticsDichotomous)
politics_chi <- chisq.test(politics_counts, p = c(.50, .50))

party_counts
prop.table(party_counts)
party_chi
politics_counts
prop.table(politics_counts)
politics_chi

