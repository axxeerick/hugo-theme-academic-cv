# Exploring Statistics with R: Chapter 11: Analysis of Variance
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# Give Adult readable labels in a meaningful order.

eammi <- eammi |>
  mutate(
    Adult = factor(
      Adult,
      levels = c(3, 2, 1),
      labels = c("No", "Maybe", "Yes")
    )
  )

# Calculate IQR boundaries for the markers-of-adulthood scores.

moa_bounds <- eammi |>
  summarise(
    Q1 = quantile(MOA_ACH, 0.25),
    Q3 = quantile(MOA_ACH, 0.75),
    IQR = IQR(MOA_ACH),
    LowerBoundary = Q1 - (1.5 * IQR),
    UpperBoundary = Q3 + (1.5 * IQR)
  )

moa_bounds

# Set aside potential outliers and incomplete observations for this analysis.

moa_adult_data <- eammi |>
  filter(
    MOA_ACH >= moa_bounds$LowerBoundary,
    MOA_ACH <= moa_bounds$UpperBoundary
  ) |>
  drop_na(MOA_ACH, Adult)

# ---- Run ----

# Summarize markers-of-adulthood scores within each adult-status group.

moa_adult_summary <- moa_adult_data |>
  group_by(Adult) |>
  summarise(
    N = n(),
    Mean = mean(MOA_ACH),
    SD = sd(MOA_ACH),
    SE = SD / sqrt(N),
    LowerCI = Mean - qt(0.975, df = N - 1) * SE,
    UpperCI = Mean + qt(0.975, df = N - 1) * SE,
    Skewness = sample_skewness(MOA_ACH)
  )

moa_adult_summary

# Fit the ANOVA, check equal variance and normality, then inspect all three outputs.

moa_adult_anova <- aov(
  MOA_ACH ~ Adult,
  data = moa_adult_data
)

moa_variance_test <- bartlett.test(
  MOA_ACH ~ Adult,
  data = moa_adult_data
)

moa_normality_test <- shapiro.test(
  residuals(moa_adult_anova)
)

moa_variance_test
moa_normality_test
summary(moa_adult_anova)

# ---- Investigate ----

# Use the setup file's anova_eta_squared() helper with the saved model.

moa_eta_squared <- anova_eta_squared(
  moa_adult_anova,
  "Adult"
)

moa_eta_squared

# Compare every pair of adult-status groups with adjusted p values.

moa_tukey <- TukeyHSD(moa_adult_anova)

moa_tukey

# ---- Calculate Effect Sizes ----

# Use the setup file's tukey_cohens_d() helper for each group comparison.

moa_pairwise_d <- tukey_cohens_d(
  moa_adult_anova,
  moa_tukey,
  "Adult"
)

moa_pairwise_d

# Figure: Mean achieved independence by adult identity.

moa_adult_summary |>
  ggplot(aes(x = Adult, y = Mean)) +
  geom_errorbar(
    aes(ymin = LowerCI, ymax = UpperCI),
    width = 0.12
  ) +
  geom_point(size = 3) +
  labs(
    x = "Adult identity",
    y = "Mean achieved independence"
  )

# ---- Research Question 2 ----

# Check Your Work: complete the self-efficacy ANOVA workflow.

self_efficacy_data <- eammi |>
  drop_na(SelfEfficacy, Adult)

self_efficacy_summary <- self_efficacy_data |>
  group_by(Adult) |>
  summarise(
    N = n(),
    Mean = mean(SelfEfficacy),
    SD = sd(SelfEfficacy),
    SE = SD / sqrt(N),
    LowerCI = Mean - qt(0.975, df = N - 1) * SE,
    UpperCI = Mean + qt(0.975, df = N - 1) * SE,
    Skewness = sample_skewness(SelfEfficacy)
  )

self_efficacy_anova <- aov(
  SelfEfficacy ~ Adult,
  data = self_efficacy_data
)

self_efficacy_variance_test <- bartlett.test(
  SelfEfficacy ~ Adult,
  data = self_efficacy_data
)

self_efficacy_normality_test <- shapiro.test(
  residuals(self_efficacy_anova)
)

self_efficacy_eta_squared <- anova_eta_squared(
  self_efficacy_anova,
  "Adult"
)

self_efficacy_tukey <- TukeyHSD(self_efficacy_anova)
self_efficacy_pairwise_d <- tukey_cohens_d(
  self_efficacy_anova,
  self_efficacy_tukey,
  "Adult"
)

self_efficacy_summary
self_efficacy_variance_test
self_efficacy_normality_test
summary(self_efficacy_anova)
self_efficacy_eta_squared
self_efficacy_tukey
self_efficacy_pairwise_d

# Check Your Work: graph the self-efficacy means and 95% confidence intervals.

# Figure: Mean self-efficacy by adult identity.

self_efficacy_summary |>
  ggplot(aes(x = Adult, y = Mean)) +
  geom_errorbar(
    aes(ymin = LowerCI, ymax = UpperCI),
    width = 0.12
  ) +
  geom_point(size = 3) +
  labs(
    x = "Adult identity",
    y = "Mean self-efficacy"
  )

# ---- Research Question 3 ----

# Check Your Work: complete the stress-by-living-status ANOVA workflow.

eammi <- eammi |>
  mutate(
    NoLongerHome = factor(
      NoLongerHome,
      levels = c(1, 2, 3),
      labels = c("No", "Somewhat", "Yes")
    )
  )

stress_home_data <- eammi |>
  drop_na(Stress, NoLongerHome)

stress_home_summary <- stress_home_data |>
  group_by(NoLongerHome) |>
  summarise(
    N = n(),
    Mean = mean(Stress),
    SD = sd(Stress),
    SE = SD / sqrt(N),
    Skewness = sample_skewness(Stress)
  )

stress_home_anova <- aov(
  Stress ~ NoLongerHome,
  data = stress_home_data
)

stress_home_variance_test <- bartlett.test(
  Stress ~ NoLongerHome,
  data = stress_home_data
)

stress_home_normality_test <- shapiro.test(
  residuals(stress_home_anova)
)

stress_home_eta_squared <- anova_eta_squared(
  stress_home_anova,
  "NoLongerHome"
)

stress_home_summary
stress_home_variance_test
stress_home_normality_test
summary(stress_home_anova)
stress_home_eta_squared

