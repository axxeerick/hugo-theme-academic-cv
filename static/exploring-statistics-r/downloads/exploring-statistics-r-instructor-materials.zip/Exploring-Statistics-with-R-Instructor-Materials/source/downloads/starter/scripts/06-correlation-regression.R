# Exploring Statistics with R: Chapter 6: Correlation and Regression
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# ---- Run ----

# Calculate the correlation between stress and family support.

family_correlation <- cor(
  eammi$Stress,
  eammi$SupportFamily,
  use = "complete.obs"
)

family_correlation

# Build a correlation matrix for stress and all three support variables.

support_correlations <- eammi |>
  select(Stress, SupportFamily, SupportFriends, SupportSpecial) |>
  cor(use = "pairwise.complete.obs")

support_correlations

# ---- Investigate ----

# Square every correlation to calculate shared variance.

support_correlations^2

# ---- Fit Regression Models ----

# Predict stress from family support with a linear model.

family_model <- lm(Stress ~ SupportFamily, data = eammi)

coefficients(family_model)

# Refit the same model pattern with friend and special-someone support.

friends_model <- lm(Stress ~ SupportFriends, data = eammi)
special_model <- lm(Stress ~ SupportSpecial, data = eammi)

coefficients(friends_model)
coefficients(special_model)

# Add observed points, then layer the fitted regression line on the same graph.

# Figure: Perceived stress by perceived social support from family.

eammi |>
  drop_na(Stress, SupportFamily) |>
  ggplot(aes(x = SupportFamily, y = Stress)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE) +
  labs(
    x = "Perceived social support from family",
    y = "Perceived stress score"
  )

