# Exploring Statistics with R: Chapters 3 and 4: Central Tendency and Variability
# Run one complete expression at a time as you work through the chapter.

# ---- Open the Chapter 3/4 script ----

source("scripts/_setup.R")

# Give the NoLongerHome codes meaningful ordered labels.

eammi <- eammi |>
  mutate(
    NoLongerHome = factor(
      NoLongerHome,
      levels = c(1, 2, 3),
      labels = c("No", "Somewhat", "Yes"),
      ordered = TRUE
    )
  )

# ---- Inspect The Observed Range ----

# Calculate grouped descriptives; statistical_mode() is supplied by the setup file.

eammi |>
  drop_na(NoLongerHome) |>
  group_by(NoLongerHome) |>
  summarise(
    N = n(),
    Missing = sum(is.na(IMPcareer)),
    Mean = mean(IMPcareer, na.rm = TRUE),
    Median = median(IMPcareer, na.rm = TRUE),
    Mode = statistical_mode(IMPcareer),
    SD = sd(IMPcareer, na.rm = TRUE),
    Minimum = min(IMPcareer, na.rm = TRUE),
    Maximum = max(IMPcareer, na.rm = TRUE)
  )

# ---- Check The Data ----

# Count observations outside the valid 0-to-100 range.

eammi |>
  filter(IMPcareer > 100) |>
  count(NoLongerHome, IMPcareer, name = "Frequency")

# ---- Recalculate The Summary ----

# Set aside the impossible value and recalculate the grouped statistics.

career_summary <- eammi |>
  filter(IMPcareer >= 0, IMPcareer <= 100) |>
  drop_na(NoLongerHome) |>
  group_by(NoLongerHome) |>
  summarise(
    N = n(),
    Mean = mean(IMPcareer),
    Median = median(IMPcareer),
    Mode = statistical_mode(IMPcareer),
    SD = sd(IMPcareer),
    Minimum = min(IMPcareer),
    Maximum = max(IMPcareer)
  )

career_summary

# ---- Compare Distribution Shapes ----

# Figure: Career-importance ratings by whether participants have moved out of their parents' home.

eammi |>
  filter(IMPcareer >= 0, IMPcareer <= 100) |>
  drop_na(NoLongerHome) |>
  ggplot(aes(x = IMPcareer)) +
  geom_histogram(binwidth = 5, boundary = 0) +
  facet_wrap(~ NoLongerHome, ncol = 1) +
  labs(
    x = "Career importance rating",
    y = "Frequency"
  )

