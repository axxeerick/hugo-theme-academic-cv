# Exploring Statistics with R
# Open and check the EAMMi2 data
#
# Open exploring-statistics-r.Rproj before running this script.
# Run one complete section at a time with the Run button.

# ---- Prepare the R tools and data ----

if (!file.exists("scripts/_setup.R")) {
  stop(
    "Open exploring-statistics-r.Rproj, then run this script again.",
    call. = FALSE
  )
}

source("scripts/_setup.R")

# ---- Confirm the data opened correctly ----

# Count the observations and variables.
nrow(eammi)
ncol(eammi)

# List the variable names.
names(eammi)

# View the data frame structure.
glimpse(eammi)

# Create a small frequency table.
eammi |>
  count(Gender, name = "Frequency")

# ---- Practice reading R code ----

# Store a value in an object, then print the object.
favorite_number <- 7
favorite_number

# Use a function to round a value to two decimal places.
round(21.428, digits = 2)

# Store a table created with a pipe, then print the table.
gender_counts <- eammi |>
  count(Gender, name = "Frequency")

gender_counts
