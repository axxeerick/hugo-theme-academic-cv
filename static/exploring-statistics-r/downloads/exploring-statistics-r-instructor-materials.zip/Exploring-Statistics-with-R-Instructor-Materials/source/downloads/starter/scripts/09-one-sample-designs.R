# Exploring Statistics with R: Chapter 9: One-Sample Designs
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# ---- Run ----

# Run an initial comparison with the 30-minute estimate, but do not interpret it yet.

duration_first_test <- t.test(
  eammi$Duration,
  mu = 30,
  alternative = "two.sided"
)

duration_first_test

# Inspect survey duration before deciding whether the initial test is trustworthy.

duration_first_summary <- eammi |>
  summarise(
    N = n(),
    Mean = mean(Duration),
    Median = median(Duration),
    SD = sd(Duration),
    Minimum = min(Duration),
    Q1 = quantile(Duration, 0.25),
    Q3 = quantile(Duration, 0.75),
    IQR = IQR(Duration),
    Maximum = max(Duration),
    Skewness = sample_skewness(Duration)
  )

duration_first_summary

# Figure: Survey duration before potential upper outliers are set aside.

eammi |>
  ggplot(aes(x = Duration)) +
  geom_histogram(binwidth = 100, boundary = 0) +
  labs(
    x = "Survey duration in minutes",
    y = "Frequency"
  )

# ---- Investigate ----

# Calculate boundaries that flag potential survey-duration outliers.

duration_bounds <- eammi |>
  summarise(
    Q1 = quantile(Duration, 0.25),
    Q3 = quantile(Duration, 0.75),
    IQR = IQR(Duration),
    LowerBoundary = Q1 - (1.5 * IQR),
    UpperBoundary = Q3 + (1.5 * IQR)
  )

duration_bounds

# ---- Screen And Reanalyze ----

# Set aside durations above the upper boundary while preserving the original data frame.

duration_upper_boundary <- duration_bounds$UpperBoundary

duration_no_outliers <- eammi |>
  filter(Duration <= duration_upper_boundary)

# Recheck the duration distribution after the data decision.

duration_filtered_summary <- duration_no_outliers |>
  summarise(
    N = n(),
    Mean = mean(Duration),
    Median = median(Duration),
    SD = sd(Duration),
    Minimum = min(Duration),
    Q1 = quantile(Duration, 0.25),
    Q3 = quantile(Duration, 0.75),
    IQR = IQR(Duration),
    Maximum = max(Duration),
    Skewness = sample_skewness(Duration)
  )

duration_filtered_summary

# Figure: Survey duration after potential upper outliers are set aside.

duration_no_outliers |>
  ggplot(aes(x = Duration)) +
  geom_histogram(binwidth = 5, boundary = 0) +
  labs(
    x = "Survey duration in minutes",
    y = "Frequency"
  )

# Run the final one-sample t test on the screened duration data.

duration_final_test <- t.test(
  duration_no_outliers$Duration,
  mu = 30,
  alternative = "two.sided"
)

duration_final_test

# ---- Calculate Cohen's d ----

# Calculate the mean difference and confidence interval, then use the setup file's cohens_d() helper.

duration_mean_difference <- mean(duration_no_outliers$Duration) - 30
duration_difference_ci <- duration_final_test$conf.int - 30

duration_d <- cohens_d(
  duration_mean_difference,
  sd(duration_no_outliers$Duration)
)

duration_mean_difference
duration_difference_ci
duration_d

# ---- Research Question 2 ----

# Check Your Work: inspect the mindfulness distribution.

mindfulness_summary <- eammi |>
  summarise(
    N = n(),
    Mean = mean(Mindfulness),
    Median = median(Mindfulness),
    SD = sd(Mindfulness),
    Minimum = min(Mindfulness),
    Maximum = max(Mindfulness),
    Skewness = sample_skewness(Mindfulness)
  )

mindfulness_summary

# Figure: Mindfulness scores in the reduced EAMMi2 sample.

eammi |>
  ggplot(aes(x = Mindfulness)) +
  geom_histogram(binwidth = 0.25, boundary = 0) +
  labs(
    x = "Mindfulness score",
    y = "Frequency"
  )

# Check Your Work: compare emerging adults with the Zen-practitioner mean.

mindfulness_zen_test <- t.test(
  eammi$Mindfulness,
  mu = 4.29,
  alternative = "two.sided"
)

mindfulness_zen_difference <- mean(eammi$Mindfulness) - 4.29
mindfulness_zen_ci <- mindfulness_zen_test$conf.int - 4.29
mindfulness_zen_d <- cohens_d(
  mindfulness_zen_difference,
  sd(eammi$Mindfulness)
)

mindfulness_zen_test
mindfulness_zen_ci
mindfulness_zen_d

# Check Your Work: compare emerging adults with the undergraduate mean.

mindfulness_undergraduate_test <- t.test(
  eammi$Mindfulness,
  mu = 3.85,
  alternative = "two.sided"
)

mindfulness_undergraduate_difference <- mean(eammi$Mindfulness) - 3.85
mindfulness_undergraduate_ci <- mindfulness_undergraduate_test$conf.int - 3.85
mindfulness_undergraduate_d <- cohens_d(
  mindfulness_undergraduate_difference,
  sd(eammi$Mindfulness)
)

mindfulness_undergraduate_test
mindfulness_undergraduate_ci
mindfulness_undergraduate_d

