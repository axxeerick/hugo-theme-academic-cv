# Exploring Statistics with R: Chapter 12: Analysis of Variance
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# Create a participant label and keep the three social media ratings.

social_media_wide <- eammi |>
  mutate(
    Participant = factor(row_number())
  ) |>
  select(
    Participant,
    SMmaintain,
    SMnewconnect,
    SMinformation
  ) |>
  drop_na(
    SMmaintain,
    SMnewconnect,
    SMinformation
  )

head(social_media_wide, n = 3)

# ---- Run And Investigate: Reshape The Data ----

# Reshape the ratings so each participant has one row for each reason.

social_media_long <- social_media_wide |>
  pivot_longer(
    cols = c(SMmaintain, SMnewconnect, SMinformation),
    names_to = "Reason",
    values_to = "SMUse"
  ) |>
  mutate(
    Reason = factor(
      Reason,
      levels = c("SMmaintain", "SMnewconnect", "SMinformation"),
      labels = c(
        "Maintain existing connections",
        "Make new connections",
        "Get information"
      )
    )
  )

head(social_media_long, n = 9)

# ---- Run The Analysis ----

# Summarize each reason and calculate 95% confidence intervals for the graph.

social_media_summary <- social_media_long |>
  group_by(Reason) |>
  summarise(
    N = n(),
    Mean = mean(SMUse),
    SD = sd(SMUse),
    SE = SD / sqrt(N),
    LowerCI = Mean - qt(0.975, df = N - 1) * SE,
    UpperCI = Mean + qt(0.975, df = N - 1) * SE
  )

social_media_summary

# Fit the repeated-measures model. This step may take about 30 seconds.

social_media_anova <- aov(
  SMUse ~ Reason + factor(Participant),
  data = social_media_long
)

summary(social_media_anova)

# Use the setup file's repeated_eta_squared() helper with the fitted model.

social_media_eta_squared <- repeated_eta_squared(
  social_media_anova,
  "Reason"
)

social_media_eta_squared

# Use the setup file's repeated_pairwise_tests() helper; this may take several seconds.

social_media_pairwise <- repeated_pairwise_tests(
  social_media_long,
  SMUse,
  Reason,
  Participant,
  anova_model = social_media_anova
)

social_media_pairwise

# ---- Inspect And Interpret ----

# Figure: Mean social media use by reason for use.

social_media_summary |>
  ggplot(aes(x = Reason, y = Mean)) +
  geom_errorbar(
    aes(ymin = LowerCI, ymax = UpperCI),
    width = 0.12
  ) +
  geom_point(size = 3) +
  coord_flip() +
  labs(
    x = "Reason for using social media",
    y = "Mean social media use"
  )

# ---- Research Question 2 ----

# Check Your Work: reshape the three support ratings into long format.

support_wide <- eammi |>
  mutate(Participant = factor(row_number())) |>
  select(Participant, SupportFamily, SupportFriends, SupportSpecial) |>
  drop_na(SupportFamily, SupportFriends, SupportSpecial)

support_long <- support_wide |>
  pivot_longer(
    cols = c(SupportFamily, SupportFriends, SupportSpecial),
    names_to = "SupportSource",
    values_to = "Support"
  ) |>
  mutate(
    SupportSource = factor(
      SupportSource,
      levels = c("SupportFamily", "SupportFriends", "SupportSpecial"),
      labels = c("Family", "Friends", "Special someone")
    )
  )

# Summarize each support source and calculate 95% confidence intervals.

support_summary <- support_long |>
  group_by(SupportSource) |>
  summarise(
    N = n(),
    Mean = mean(Support),
    SD = sd(Support),
    SE = SD / sqrt(N),
    LowerCI = Mean - qt(0.975, df = N - 1) * SE,
    UpperCI = Mean + qt(0.975, df = N - 1) * SE
  )

support_summary

# Fit the support model. This step may take about 30 seconds.

support_anova <- aov(
  Support ~ SupportSource + factor(Participant),
  data = support_long
)

summary(support_anova)

# Use the setup-file helpers for effect size and paired comparisons; the latter may take several seconds.

support_eta_squared <- repeated_eta_squared(support_anova, "SupportSource")
support_pairwise <- repeated_pairwise_tests(
  support_long,
  Support,
  SupportSource,
  Participant,
  anova_model = support_anova
)

support_eta_squared
support_pairwise

# Figure: Mean social support by source.

support_summary |>
  ggplot(aes(x = SupportSource, y = Mean)) +
  geom_errorbar(
    aes(ymin = LowerCI, ymax = UpperCI),
    width = 0.12
  ) +
  geom_point(size = 3) +
  coord_flip() +
  labs(
    x = "Source of social support",
    y = "Mean social support"
  )

