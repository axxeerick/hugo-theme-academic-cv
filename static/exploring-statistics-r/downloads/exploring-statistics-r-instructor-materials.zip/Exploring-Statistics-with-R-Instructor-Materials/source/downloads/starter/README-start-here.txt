Exploring Statistics with R - Starter Files

1. Open RStudio.
2. Choose File > Open Project...
3. Select exploring-statistics-r.Rproj from this folder.
4. In the Output pane, click the Files tab and open scripts/00-open-and-check-data.R.
5. Place your cursor in the first section and click Run. Continue running
   one complete section at a time.

The script should create an object named eammi and print:
- 2073 observations
- 39 variables
- a list of variable names
- a small frequency table for Gender

The final section contains short examples of objects, functions, pipes,
and comments. Run these examples one at a time.

The first run may take a few minutes because the setup file checks for
the R tools used in the scripts and installs them if needed.

After the starter script works, open scripts/01-introduction.R for the
Chapter 1 code. Open scripts/02-frequency-distributions.R for the
Chapter 2 code. Open scripts/03-04-central-tendency-variability.R for
the Chapters 3 and 4 code. Open scripts/05-other-descriptive-statistics.R
for the Chapter 5 code. Open scripts/06-correlation-regression.R for
the Chapter 6 code. Open scripts/09-one-sample-designs.R for the
Chapter 9 code. Open scripts/10-two-sample-designs.R for the Chapter
10 code. Open scripts/11-anova-independent.R for the Chapter 11 code.
Open scripts/12-anova-repeated.R for the Chapter 12 code. Open
scripts/13-two-way-anova.R for the Chapter 13 code. Open
scripts/14-chi-square.R for the Chapter 14 code. Open
scripts/15-nonparametric-statistics.R for the Chapter 15 code.

The resources folder includes EAMMI2_Survey_withcodes.pdf, which shows
the original survey questions and response codes.
