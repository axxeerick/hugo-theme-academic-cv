# Exploring Statistics with R: Chapter 5: Other Descriptive Statistics
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# Give Disability readable category labels before comparing groups.

eammi <- eammi |>
  mutate(
    Disability = factor(
      Disability,
      levels = c(1, 2),
      labels = c("Yes", "No")
    )
  )

# ---- Describe Stress ----

# Calculate a complete set of descriptive statistics for Stress.

stress_summary <- eammi |>
  drop_na(Stress) |>
  summarise(
    N = n(),
    Mean = mean(Stress),
    Median = median(Stress),
    Mode = statistical_mode(Stress),
    SD = sd(Stress),
    Minimum = min(Stress),
    Maximum = max(Stress),
    Range = Maximum - Minimum,
    Q1 = quantile(Stress, 0.25),
    Q3 = quantile(Stress, 0.75),
    IQR = IQR(Stress)
  )

stress_summary

# ---- Investigate The Code ----

# Figure: Distribution of perceived stress scores in the reduced EAMMi2 sample.

eammi |>
  drop_na(Stress) |>
  ggplot(aes(x = Stress)) +
  geom_histogram(binwidth = 1, boundary = 0) +
  labs(
    x = "Perceived stress score",
    y = "Frequency"
  )

# ---- Create Z Scores ----

# Inspect the first stress scores before creating a new variable.

head(eammi$Stress, n = 2)

# Add a z score for Stress to every observation in the data frame.

eammi <- eammi |>
  mutate(
    Stress_z = (Stress - mean(Stress, na.rm = TRUE)) / sd(Stress, na.rm = TRUE)
  )

head(eammi$Stress_z, n = 2)

# Find the smallest and largest stress z scores.

eammi |>
  drop_na(Stress_z) |>
  summarise(
    Mean = mean(Stress_z),
    SD = sd(Stress_z),
    Minimum = min(Stress_z),
    Maximum = max(Stress_z)
  )

# ---- Identify Potential Outliers With IQR ----

# Calculate the IQR boundaries used to flag potential outliers.

stress_iqr <- eammi |>
  drop_na(Stress) |>
  summarise(
    Q1 = quantile(Stress, 0.25),
    Q3 = quantile(Stress, 0.75),
    IQR = IQR(Stress),
    LowerBoundary = Q1 - (1.5 * IQR),
    UpperBoundary = Q3 + (1.5 * IQR)
  )

stress_iqr

# Figure: Boxplot of perceived stress scores in the reduced EAMMi2 sample.

eammi |>
  drop_na(Stress) |>
  ggplot(aes(y = Stress)) +
  geom_boxplot() +
  labs(
    x = NULL,
    y = "Perceived stress score"
  )

# ---- Filter The Potential Outliers ----

# Create a new data frame that sets aside scores outside the IQR boundaries.

stress_filtered <- eammi |>
  filter(Stress > 22.5, Stress < 42.5)

# Recalculate descriptive statistics after potential outliers are set aside.

stress_filtered_summary <- stress_filtered |>
  summarise(
    N = n(),
    Mean = mean(Stress),
    Median = median(Stress),
    Mode = statistical_mode(Stress),
    SD = sd(Stress),
    Minimum = min(Stress),
    Maximum = max(Stress),
    Range = Maximum - Minimum,
    Q1 = quantile(Stress, 0.25),
    Q3 = quantile(Stress, 0.75),
    IQR = IQR(Stress)
  )

stress_filtered_summary

# Figure: Distribution of perceived stress after scores outside the original IQR boundaries were filtered.

stress_filtered |>
  ggplot(aes(x = Stress)) +
  geom_histogram(binwidth = 1, boundary = 0) +
  labs(
    x = "Perceived stress score",
    y = "Frequency"
  )

# Figure: Boxplot of perceived stress after scores outside the original IQR boundaries were filtered.

stress_filtered |>
  ggplot(aes(y = Stress)) +
  geom_boxplot() +
  labs(
    x = NULL,
    y = "Perceived stress score"
  )

# ---- Compare Stress By Disability Status ----

# Compare stress descriptives for participants with and without a disability.

stress_disability_summary <- stress_filtered |>
  drop_na(Disability) |>
  group_by(Disability) |>
  summarise(
    N = n(),
    Mean = mean(Stress),
    Median = median(Stress),
    Mode = statistical_mode(Stress),
    SD = sd(Stress),
    Minimum = min(Stress),
    Maximum = max(Stress),
    Range = Maximum - Minimum,
    Q1 = quantile(Stress, 0.25),
    Q3 = quantile(Stress, 0.75),
    IQR = IQR(Stress)
  )

stress_disability_summary

# Figure: Filtered perceived stress scores for participants with and without a disability.

stress_filtered |>
  drop_na(Disability) |>
  ggplot(aes(x = Disability, y = Stress)) +
  geom_boxplot() +
  labs(
    x = "Identifies as having a disability",
    y = "Perceived stress score"
  )

# ---- Calculate Cohen's d ----

# Use the setup file's independent_cohens_d() helper to compare the two groups.

stress_disability_d <- independent_cohens_d(
  stress_filtered,
  Stress,
  Disability
)

stress_disability_d

# ---- Inspect The Original Variable ----

# Check Your Work: inspect the original MOA_ACH distribution.

moa_original_summary <- eammi |>
  drop_na(MOA_ACH) |>
  summarise(
    N = n(),
    Mean = mean(MOA_ACH),
    Median = median(MOA_ACH),
    Mode = statistical_mode(MOA_ACH),
    SD = sd(MOA_ACH),
    Minimum = min(MOA_ACH),
    Maximum = max(MOA_ACH),
    Range = Maximum - Minimum,
    Q1 = quantile(MOA_ACH, 0.25),
    Q3 = quantile(MOA_ACH, 0.75),
    IQR = IQR(MOA_ACH)
  )

moa_original_summary

# Figure: Original distribution of markers of adulthood achieved.

eammi |>
  drop_na(MOA_ACH) |>
  ggplot(aes(x = MOA_ACH)) +
  geom_histogram(binwidth = 1, boundary = 20) +
  labs(
    x = "Markers of adulthood achieved",
    y = "Frequency"
  )

# Figure: Original boxplot for markers of adulthood achieved.

eammi |>
  drop_na(MOA_ACH) |>
  ggplot(aes(y = MOA_ACH)) +
  geom_boxplot() +
  labs(
    x = NULL,
    y = "Markers of adulthood achieved"
  )

# Check Your Work: calculate IQR boundaries for MOA_ACH.

moa_iqr <- eammi |>
  drop_na(MOA_ACH) |>
  summarise(
    Q1 = quantile(MOA_ACH, 0.25),
    Q3 = quantile(MOA_ACH, 0.75),
    IQR = IQR(MOA_ACH),
    LowerBoundary = Q1 - (1.5 * IQR),
    UpperBoundary = Q3 + (1.5 * IQR)
  )

moa_iqr

# ---- Filter And Describe The Variable ----

# Check Your Work: set aside MOA_ACH scores beyond the IQR boundaries.

moa_filtered <- eammi |>
  filter(MOA_ACH > 23.5, MOA_ACH < 51.5)

# Check Your Work: summarize the filtered MOA_ACH scores.

moa_filtered_summary <- moa_filtered |>
  summarise(
    N = n(),
    Mean = mean(MOA_ACH),
    Median = median(MOA_ACH),
    Mode = statistical_mode(MOA_ACH),
    SD = sd(MOA_ACH),
    Minimum = min(MOA_ACH),
    Maximum = max(MOA_ACH),
    Range = Maximum - Minimum,
    Q1 = quantile(MOA_ACH, 0.25),
    Q3 = quantile(MOA_ACH, 0.75),
    IQR = IQR(MOA_ACH)
  )

moa_filtered_summary

# Figure: Filtered distribution of markers of adulthood achieved.

moa_filtered |>
  ggplot(aes(x = MOA_ACH)) +
  geom_histogram(binwidth = 1, boundary = 20) +
  labs(
    x = "Markers of adulthood achieved",
    y = "Frequency"
  )

# Figure: Filtered boxplot for markers of adulthood achieved.

moa_filtered |>
  ggplot(aes(y = MOA_ACH)) +
  geom_boxplot() +
  labs(
    x = NULL,
    y = "Markers of adulthood achieved"
  )

# ---- Compare Political-Party Groups ----

# Check Your Work: give political-party codes readable labels.

moa_filtered <- moa_filtered |>
  mutate(
    PartyDichotomous = factor(
      PartyDichotomous,
      levels = c(1, 2),
      labels = c("Democrat", "Republican")
    )
  )

# Check Your Work: compare MOA_ACH descriptives across party groups.

moa_party_summary <- moa_filtered |>
  drop_na(PartyDichotomous) |>
  group_by(PartyDichotomous) |>
  summarise(
    N = n(),
    Mean = mean(MOA_ACH),
    Median = median(MOA_ACH),
    Mode = statistical_mode(MOA_ACH),
    SD = sd(MOA_ACH),
    Minimum = min(MOA_ACH),
    Maximum = max(MOA_ACH),
    Range = Maximum - Minimum,
    Q1 = quantile(MOA_ACH, 0.25),
    Q3 = quantile(MOA_ACH, 0.75),
    IQR = IQR(MOA_ACH)
  )

moa_party_summary

# Figure: Filtered markers-of-adulthood scores for Democrats and Republicans.

moa_filtered |>
  drop_na(PartyDichotomous) |>
  ggplot(aes(x = PartyDichotomous, y = MOA_ACH)) +
  geom_boxplot() +
  labs(
    x = "Political-party identification",
    y = "Markers of adulthood achieved"
  )

# Check Your Work: calculate Cohen's d for the party-group difference.

moa_party_d <- independent_cohens_d(
  moa_filtered,
  MOA_ACH,
  PartyDichotomous
)

moa_party_d

