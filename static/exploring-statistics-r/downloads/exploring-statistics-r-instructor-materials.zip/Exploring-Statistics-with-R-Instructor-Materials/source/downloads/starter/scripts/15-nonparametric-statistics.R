# Exploring Statistics with R: Chapter 15: Nonparametric Statistics
# Run one complete expression at a time as you work through the chapter.

# ---- Get Ready ----

source("scripts/_setup.R")

# Add the four importance ratings to check whether each participant assigned exactly 100 points.

eammi <- eammi |>
  mutate(
    IMPtotal = IMPmarriage + IMPparenting + IMPcareer + IMPhobbies,
    PartyDichotomous = factor(
      PartyDichotomous,
      levels = c(1, 2),
      labels = c("Democrat", "Republican")
    ),
    Adult = factor(
      Adult,
      levels = c(3, 2, 1),
      labels = c("No", "Maybe", "Yes")
    )
  )

importance_check <- eammi |>
  summarise(
    FollowedDirections = sum(IMPtotal == 100, na.rm = TRUE),
    DidNotFollowDirections = sum(IMPtotal != 100, na.rm = TRUE),
    MissingTotal = sum(is.na(IMPtotal))
  )

importance_check

# Keep participants whose four importance ratings total exactly 100.

importance_data <- eammi |>
  filter(IMPtotal == 100)

# ---- Run The Analysis ----

# Summarize hobby-importance ratings for Democrats and Republicans.

hobbies_party_data <- importance_data |>
  drop_na(IMPhobbies, PartyDichotomous)

hobbies_party_summary <- hobbies_party_data |>
  group_by(PartyDichotomous) |>
  summarise(
    N = n(),
    Mean = mean(IMPhobbies),
    Median = median(IMPhobbies),
    SD = sd(IMPhobbies),
    .groups = "drop"
  )

hobbies_party_summary

# Compare hobby-importance ranks for Democrats and Republicans.

hobbies_party_test <- wilcox.test(
  IMPhobbies ~ PartyDichotomous,
  data = hobbies_party_data,
  exact = FALSE
)

hobbies_party_test

# Use the setup file's rank_biserial_independent() helper for the effect size.

hobbies_party_effect <- rank_biserial_independent(
  hobbies_party_test,
  hobbies_party_data$PartyDichotomous
)

hobbies_party_effect

# Figure: Hobby-importance ratings by political party.

hobbies_party_data |>
  ggplot(aes(x = PartyDichotomous, y = IMPhobbies)) +
  geom_boxplot() +
  labs(
    x = "Political party",
    y = "Importance assigned to hobbies"
  )

# ---- Get Ready ----

# Summarize career and hobby ratings from the same participants.

career_summary <- importance_data |>
  summarise(
    N = n(),
    Mean = mean(IMPcareer),
    Median = median(IMPcareer),
    SD = sd(IMPcareer)
  )

hobby_summary <- importance_data |>
  summarise(
    N = n(),
    Mean = mean(IMPhobbies),
    Median = median(IMPhobbies),
    SD = sd(IMPhobbies)
  )

career_summary
hobby_summary

# ---- Run The Analysis ----

# Compare career and hobby ratings from the same participants.

career_hobby_test <- wilcox.test(
  importance_data$IMPcareer,
  importance_data$IMPhobbies,
  paired = TRUE,
  exact = FALSE
)

career_hobby_test

# Use the setup file's rank_biserial_paired() helper for the paired effect size.

career_hobby_effect <- rank_biserial_paired(
  importance_data$IMPcareer,
  importance_data$IMPhobbies
)

career_hobby_effect

# Summarize career importance for the three adult-status groups.

career_adult_data <- importance_data |>
  drop_na(IMPcareer, Adult)

career_adult_summary <- career_adult_data |>
  group_by(Adult) |>
  summarise(
    N = n(),
    Mean = mean(IMPcareer),
    Median = median(IMPcareer),
    SD = sd(IMPcareer),
    .groups = "drop"
  )

career_adult_summary

# Compare career-importance ranks across adult-status groups.

career_adult_test <- kruskal.test(
  IMPcareer ~ Adult,
  data = career_adult_data
)

career_adult_test

# Use the setup file's kruskal_epsilon_squared() helper for the effect size.

career_adult_effect <- kruskal_epsilon_squared(
  career_adult_test,
  career_adult_data$Adult
)

career_adult_effect

# Test the rank-based association between hobby importance and satisfaction with life.

hobbies_swls_data <- importance_data |>
  drop_na(IMPhobbies, SWLS)

hobbies_swls_test <- cor.test(
  hobbies_swls_data$IMPhobbies,
  hobbies_swls_data$SWLS,
  method = "spearman",
  exact = FALSE
)

hobbies_swls_test
nrow(hobbies_swls_data)

# ---- Research Question 1 ----

# Check Your Work: compare career importance across political-party groups.

career_party_data <- importance_data |>
  drop_na(IMPcareer, PartyDichotomous)

career_party_summary <- career_party_data |>
  group_by(PartyDichotomous) |>
  summarise(
    N = n(),
    Mean = mean(IMPcareer),
    Median = median(IMPcareer),
    SD = sd(IMPcareer),
    .groups = "drop"
  )

career_party_test <- wilcox.test(
  IMPcareer ~ PartyDichotomous,
  data = career_party_data,
  exact = FALSE
)

career_party_effect <- rank_biserial_independent(
  career_party_test,
  career_party_data$PartyDichotomous
)

career_party_summary
career_party_test
career_party_effect

# ---- Research Question 2 ----

# Check Your Work: compare marriage and hobby ratings from the same participants.

marriage_hobby_test <- wilcox.test(
  importance_data$IMPmarriage,
  importance_data$IMPhobbies,
  paired = TRUE,
  exact = FALSE
)

marriage_hobby_effect <- rank_biserial_paired(
  importance_data$IMPmarriage,
  importance_data$IMPhobbies
)

marriage_hobby_test
marriage_hobby_effect

# ---- Research Question 3 ----

# Check Your Work: compare hobby importance across adult-status groups.

hobbies_adult_data <- importance_data |>
  drop_na(IMPhobbies, Adult)

hobbies_adult_summary <- hobbies_adult_data |>
  group_by(Adult) |>
  summarise(
    N = n(),
    Mean = mean(IMPhobbies),
    Median = median(IMPhobbies),
    SD = sd(IMPhobbies),
    .groups = "drop"
  )

hobbies_adult_test <- kruskal.test(
  IMPhobbies ~ Adult,
  data = hobbies_adult_data
)

hobbies_adult_effect <- kruskal_epsilon_squared(
  hobbies_adult_test,
  hobbies_adult_data$Adult
)

hobbies_adult_post_hoc <- dscfAllPairsTest(
  IMPhobbies ~ Adult,
  data = hobbies_adult_data
)

hobbies_adult_summary
hobbies_adult_test
hobbies_adult_effect
hobbies_adult_post_hoc

# ---- Research Question 4 ----

# Check Your Work: test the rank-based association between career importance and life satisfaction.

career_swls_data <- importance_data |>
  drop_na(IMPcareer, SWLS)

career_swls_test <- cor.test(
  career_swls_data$IMPcareer,
  career_swls_data$SWLS,
  method = "spearman",
  exact = FALSE
)

career_swls_test
nrow(career_swls_data)

