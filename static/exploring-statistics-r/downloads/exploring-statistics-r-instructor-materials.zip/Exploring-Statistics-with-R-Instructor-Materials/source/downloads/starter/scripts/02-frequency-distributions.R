# Exploring Statistics with R: Chapter 2: Exploring Data
# Run one complete expression at a time as you work through the chapter.

# ---- Open the Chapter 2 script ----

source("scripts/_setup.R")

# ---- Prepare Gender ----

# Give the Gender codes readable category labels.

eammi <- eammi |>
  mutate(
    Gender = factor(
      Gender,
      levels = c(3, 2, 1),
      labels = c("Another identity", "Female", "Male")
    )
  )

# ---- Prepare Race ----

# Give the Race codes readable category labels.

eammi <- eammi |>
  mutate(
    Race = factor(
      Race,
      levels = c(2, 6, 4, 3, 7, 8, 5, 1),
      labels = c(
        "African American",
        "Another racial identity",
        "Asian/Pacific Islander",
        "Hispanic/Latinx",
        "Multiracial (2 selected)",
        "Multiracial (3+ selected)",
        "Native American",
        "White"
      )
    )
  )

# ---- Create Frequency Tables ----

# Count gender responses and add percent and cumulative percent.

gender_table <- eammi |>
  count(Gender, name = "Frequency") |>
  mutate(
    Percent = round(100 * Frequency / sum(Frequency), 1),
    CumulativePercent = round(100 * cumsum(Frequency) / sum(Frequency), 1)
  )

gender_table

# ---- Investigate The Code ----

# Count nonmissing race responses and add percent and cumulative percent.

race_table <- eammi |>
  drop_na(Race) |>
  count(Race, name = "Frequency") |>
  mutate(
    Percent = round(100 * Frequency / sum(Frequency), 1),
    CumulativePercent = round(100 * cumsum(Frequency) / sum(Frequency), 1)
  )

race_table

# ---- Create Bar Charts ----

# Figure: Number of EAMMi2 participants in each self-reported gender category.

ggplot(gender_table, aes(x = Gender, y = Frequency)) +
  geom_col() +
  labs(
    x = "Self-reported gender",
    y = "Frequency"
  )

# Figure: Number of EAMMi2 participants in each self-reported racial identity category.

ggplot(race_table, aes(x = Race, y = Frequency)) +
  geom_col() +
  coord_flip() +
  labs(
    x = "Self-reported racial identity",
    y = "Frequency"
  )

# ---- Examine Satisfaction With Life ----

# Check how R stores the SWLS variable.

class(eammi$SWLS)

# Count every SWLS score and add percent and cumulative percent.

swls_table <- eammi |>
  count(SWLS, name = "Frequency") |>
  mutate(
    Percent = round(100 * Frequency / sum(Frequency), 1),
    CumulativePercent = round(100 * cumsum(Frequency) / sum(Frequency), 1)
  )

print(swls_table, n = 32)

# ---- Pause And Inspect ----

# Figure: Distribution of Satisfaction With Life Scale scores in the reduced EAMMi2 sample.

ggplot(eammi, aes(x = SWLS)) +
  geom_histogram(binwidth = 1, boundary = 0) +
  labs(
    x = "Satisfaction With Life Scale score",
    y = "Frequency"
  )

# ---- Get Ready ----

# Give the Adult and NoLongerHome codes meaningful ordered labels.

eammi <- eammi |>
  mutate(
    Adult = factor(
      Adult,
      levels = c(3, 2, 1),
      labels = c("No", "Maybe", "Yes"),
      ordered = TRUE
    ),
    NoLongerHome = factor(
      NoLongerHome,
      levels = c(1, 2, 3),
      labels = c("No", "Somewhat", "Yes"),
      ordered = TRUE
    )
  )

# ---- Research Question 2 Code ----

# Check Your Work: create the Adult frequency table.

adult_table <- eammi |>
  drop_na(Adult) |>
  count(Adult, name = "Frequency") |>
  mutate(
    Percent = round(100 * Frequency / sum(Frequency), 1),
    CumulativePercent = round(100 * cumsum(Frequency) / sum(Frequency), 1)
  )

adult_table

# Check Your Work: create the NoLongerHome frequency table.

home_table <- eammi |>
  drop_na(NoLongerHome) |>
  count(NoLongerHome, name = "Frequency") |>
  mutate(
    Percent = round(100 * Frequency / sum(Frequency), 1),
    CumulativePercent = round(100 * cumsum(Frequency) / sum(Frequency), 1)
  )

home_table

# Figure: Number of EAMMi2 participants by self-reported adult status.

ggplot(adult_table, aes(x = Adult, y = Frequency)) +
  geom_col() +
  labs(
    x = "Response to 'Are you an adult?'",
    y = "Frequency"
  )

# Figure: Number of EAMMi2 participants by whether they have moved out of their parents' home.

ggplot(home_table, aes(x = NoLongerHome, y = Frequency)) +
  geom_col() +
  labs(
    x = "Moved out of parents' home",
    y = "Frequency"
  )

