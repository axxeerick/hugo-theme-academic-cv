# Exploring Statistics with R

Prepared by Erick Axxe

*Exploring Statistics with R* is an R workbook to accompany *Exploring Statistics: Tales of Distributions*. It is built with Quarto and provides a website, editable Word chapters, a combined PDF, and a downloadable RStudio starter project.

## Project Contents

- `index.qmd`, `start/`, `chapters/`, `data/`, `reference/`, and `instructor/` contain the Quarto source.
- `scripts/` contains the chapter scripts and shared setup helpers.
- `downloads/starter/` contains the source files used to build the student starter archive.
- `assets/`, `filters/`, and the YAML files control formatting.
- `tools/` contains the rendering and verification helpers.
- `_site/` is the rendered website.
- `output/word/` contains the rendered Word documents.
- `output/pdf/Exploring-Statistics-with-R-Complete-Collection.pdf` is the combined PDF.
- `downloads/esr-starter.zip` is the student starter archive.
- `downloads/exploring-statistics-r-instructor-materials.zip` is the complete instructor archive.

## Render And Verify

Open `exploring-statistics-r.Rproj`, then run:

```bash
Rscript tools/sync-chapter-scripts.R
quarto render
python tools/render_word.py
python tools/build_combined_pdf.py
python tools/check_site.py
python tools/check_word_files.py
```

The instructor archive README gives additional details about the included formats and recommended distribution workflow.

## Data

The workbook uses a reduced teaching copy of the Emerging Adulthood Measured at Multiple Institutions-2 (EAMMi2) data. Study information and documentation are available from the [EAMMi2 project on OSF](https://osf.io/te54b/). The OSF project record identifies the materials with a CC0 1.0 license.
