local solutions = {}
local solution_count = 0
local last_prompt_title = nil

local function has_class(el, class)
  if not el.classes then
    return false
  end

  for _, value in ipairs(el.classes) do
    if value == class then
      return true
    end
  end

  return false
end

local function stringify(inlines)
  return pandoc.utils.stringify(inlines)
end

local function extract_exercise_title(block)
  if block.t ~= "Div" or not has_class(block, "exercise") then
    return nil
  end

  for _, child in ipairs(block.content) do
    if child.t == "Header" then
      return stringify(child.content)
    end
  end

  return nil
end

local function is_solution_start(block)
  return block.t == "RawBlock"
    and block.format:match("html")
    and block.text:match("<details[^>]-class=[\"'][^\"']*solution")
end

local function is_solution_end(block)
  return block.t == "RawBlock"
    and block.format:match("html")
    and block.text:match("</details>")
end

local function is_summary_tag(block)
  return block.t == "RawBlock"
    and block.format:match("html")
    and (
      block.text:match("<summary>")
      or block.text:match("</summary>")
    )
end

local function is_summary_text(block)
  if block.t ~= "Plain" then
    return false
  end

  local text = stringify(block.content):lower()
  return text == "instructor solution"
    or text == "check your work"
end

local function solution_title()
  solution_count = solution_count + 1

  if last_prompt_title and last_prompt_title ~= "" then
    return last_prompt_title
  end

  return "Solution " .. tostring(solution_count)
end

function Pandoc(doc)
  if FORMAT ~= "docx" then
    return doc
  end

  local new_blocks = {}
  local i = 1

  while i <= #doc.blocks do
    local block = doc.blocks[i]
    local exercise_title = extract_exercise_title(block)

    if exercise_title then
      last_prompt_title = exercise_title
      table.insert(new_blocks, block)
      i = i + 1
    elseif block.t == "Header" and block.level <= 2 then
      last_prompt_title = stringify(block.content)
      table.insert(new_blocks, block)
      i = i + 1
    elseif is_solution_start(block) then
      local collected = {}
      local title = solution_title()

      i = i + 1
      while i <= #doc.blocks and not is_solution_end(doc.blocks[i]) do
        if not is_summary_tag(doc.blocks[i]) and not is_summary_text(doc.blocks[i]) then
          table.insert(collected, doc.blocks[i])
        end
        i = i + 1
      end

      table.insert(
        solutions,
        pandoc.Header(3, title)
      )
      for _, solution_block in ipairs(collected) do
        table.insert(solutions, solution_block)
      end
    else
      table.insert(new_blocks, block)
      i = i + 1
    end
  end

  if #solutions > 0 then
    table.insert(new_blocks, pandoc.HorizontalRule())
    table.insert(new_blocks, pandoc.Header(1, "Check Your Work"))

    for _, solution_block in ipairs(solutions) do
      table.insert(new_blocks, solution_block)
    end
  end

  doc.blocks = new_blocks
  return doc
end
