library(haven)
library(readr)
library(dplyr)

source_file <- "../SPSS/EAMMi2-REDUCED.sav"
output_file <- "data/EAMMi2-REDUCED.csv"

eammi_labelled <- read_sav(source_file) |>
  select(-any_of("filter_$"))

write_csv(zap_labels(eammi_labelled), output_file, na = "")
