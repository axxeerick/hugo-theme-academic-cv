#!/usr/bin/env python3
"""Check rendered HTML links, metadata, images, tables, and heading order."""

from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit


SITE = Path(__file__).resolve().parents[1] / "_site"


class PageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.ids: set[str] = set()
        self.links: list[str] = []
        self.link_text: list[tuple[str, str]] = []
        self.images: list[tuple[str, str | None]] = []
        self.headings: list[int] = []
        self.table_headers: list[int] = []
        self.lang: str | None = None
        self.author: str | None = None
        self._link_href: str | None = None
        self._link_parts: list[str] = []

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        values = dict(attrs)
        if tag == "html":
            self.lang = values.get("lang")
        if values.get("id"):
            self.ids.add(values["id"])
        if tag == "a" and values.get("href"):
            self.links.append(values["href"])
            self._link_href = values["href"]
            self._link_parts = []
        if tag == "img":
            self.images.append((values.get("src", ""), values.get("alt")))
        if len(tag) == 2 and tag[0] == "h" and tag[1].isdigit():
            self.headings.append(int(tag[1]))
        if tag == "table":
            self.table_headers.append(0)
        if tag == "th" and self.table_headers:
            self.table_headers[-1] += 1
        if tag == "meta" and values.get("name", "").lower() == "author":
            self.author = values.get("content")

    def handle_data(self, data: str) -> None:
        if self._link_href is not None:
            self._link_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self._link_href is not None:
            self.link_text.append(
                (self._link_href, " ".join(self._link_parts).strip())
            )
            self._link_href = None
            self._link_parts = []


def parse_page(path: Path) -> PageParser:
    parser = PageParser()
    parser.feed(path.read_text(encoding="utf-8"))
    return parser


def main() -> int:
    pages = sorted(SITE.rglob("*.html"))
    parsed = {page.resolve(): parse_page(page) for page in pages}
    errors: list[str] = []

    for page, document in parsed.items():
        relative = page.relative_to(SITE)
        if document.lang != "en":
            errors.append(f"{relative}: missing or unexpected page language")
        if document.author != "Erick Axxe":
            errors.append(f"{relative}: author metadata is not Erick Axxe")

        for src, alt in document.images:
            if alt is None or not alt.strip():
                errors.append(f"{relative}: image lacks alt text: {src}")
            elif Path(src).name.lower() in alt.strip().lower():
                errors.append(f"{relative}: image alt text is only a filename: {src}")

        for table_number, header_count in enumerate(document.table_headers, start=1):
            if header_count == 0:
                errors.append(f"{relative}: table {table_number} lacks header cells")

        for previous, current in zip(document.headings, document.headings[1:]):
            if current > previous + 1:
                errors.append(
                    f"{relative}: heading jumps h{previous} to h{current}"
                )

        for href, link_text in document.link_text:
            if not link_text and not href.startswith("#"):
                errors.append(f"{relative}: link lacks readable text: {href}")
            if link_text.startswith(("http://", "https://")):
                errors.append(f"{relative}: raw URL used as link text: {link_text}")

        for href in document.links:
            parts = urlsplit(href)
            if parts.scheme or parts.netloc or href.startswith(("mailto:", "tel:")):
                continue

            target_path = unquote(parts.path)
            if target_path:
                target = (page.parent / target_path).resolve()
                if target.is_dir():
                    target = target / "index.html"
            else:
                target = page

            if not target.exists():
                errors.append(
                    f"{relative}: missing target for {href}"
                )
                continue

            if parts.fragment and target.suffix.lower() == ".html":
                target_document = parsed.get(target)
                if target_document is None:
                    target_document = parse_page(target)
                    parsed[target] = target_document
                if unquote(parts.fragment) not in target_document.ids:
                    errors.append(
                        f"{relative}: missing fragment for {href}"
                    )

    if errors:
        print("\n".join(errors))
        return 1

    print(f"Checked {len(pages)} HTML pages: links and accessibility checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
