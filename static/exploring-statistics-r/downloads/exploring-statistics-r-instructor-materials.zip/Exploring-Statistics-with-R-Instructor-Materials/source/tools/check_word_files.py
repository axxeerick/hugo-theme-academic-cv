#!/usr/bin/env python3
"""Check generated Word files for integrity, metadata, structure, and links."""

from __future__ import annotations

from pathlib import Path
import zipfile

from lxml import etree


ROOT = Path(__file__).resolve().parents[1]
WORD_OUTPUT = ROOT / "output" / "word"
WP_NS = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
ADEC_NS = "http://schemas.microsoft.com/office/drawing/2017/decorative"
CP_NS = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
DC_NS = "http://purl.org/dc/elements/1.1/"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"


def main() -> int:
    documents = sorted(WORD_OUTPUT.rglob("*.docx"))
    errors: list[str] = []
    figure_count = 0
    decorative_count = 0
    table_count = 0

    for document in documents:
        with zipfile.ZipFile(document) as archive:
            bad_entry = archive.testzip()
            if bad_entry:
                errors.append(f"{document}: corrupt archive entry {bad_entry}")
                continue
            names = set(archive.namelist())
            root = etree.fromstring(archive.read("word/document.xml"))
            core = etree.fromstring(archive.read("docProps/core.xml"))
            relationships = etree.fromstring(
                archive.read("word/_rels/document.xml.rels")
            )

            author = core.find(f"{{{DC_NS}}}creator")
            if author is None or author.text != "Erick Axxe":
                errors.append(f"{document}: author metadata is not Erick Axxe")

            header_text = ""
            for name in names:
                if name.startswith("word/header") and name.endswith(".xml"):
                    header = etree.fromstring(archive.read(name))
                    header_text += " ".join(
                        header.xpath("//w:t/text()", namespaces={"w": W_NS})
                    )
            if "Exploring Statistics: Tales of Distributions" not in header_text:
                errors.append(f"{document}: textbook title missing from header")
            if "Erick Axxe" not in header_text:
                errors.append(f"{document}: author missing from header")

            for name in names:
                if name.endswith("comments.xml"):
                    comments = etree.fromstring(archive.read(name))
                    if comments.xpath("//w:comment", namespaces={"w": W_NS}):
                        errors.append(f"{document}: contains Word comments")

            for relationship in relationships:
                target = relationship.get("Target", "")
                if target.startswith("file:") or "/Users/" in target:
                    errors.append(f"{document}: local link remains: {target}")

        drawings = root.xpath("//w:drawing", namespaces={"w": W_NS})
        for drawing in drawings:
            properties = drawing.xpath(
                ".//wp:docPr",
                namespaces={"wp": WP_NS},
            )[0]
            decorative = drawing.xpath(
                ".//adec:decorative[@val='1']",
                namespaces={"adec": ADEC_NS},
            )
            if decorative:
                decorative_count += 1
            elif properties.get("descr", "").strip():
                figure_count += 1
            else:
                errors.append(f"{document}: image lacks alt text or decorative flag")

        heading_levels: list[int] = []
        for paragraph in root.xpath("//w:body/w:p", namespaces={"w": W_NS}):
            styles = paragraph.xpath("./w:pPr/w:pStyle/@w:val", namespaces={"w": W_NS})
            if styles and styles[0].lower().startswith("heading"):
                digits = "".join(character for character in styles[0] if character.isdigit())
                if digits:
                    heading_levels.append(int(digits))
        for previous, current in zip(heading_levels, heading_levels[1:]):
            if current > previous + 1:
                errors.append(
                    f"{document}: heading jumps from level {previous} to {current}"
                )

        for table in root.xpath("//w:body/w:tbl", namespaces={"w": W_NS}):
            table_count += 1
            first_rows = table.xpath("./w:tr[1]", namespaces={"w": W_NS})
            if not first_rows or not first_rows[0].xpath(
                "./w:trPr/w:tblHeader", namespaces={"w": W_NS}
            ):
                errors.append(f"{document}: body table lacks a marked header row")

    if errors:
        print("\n".join(errors))
        return 1

    print(
        f"Checked {len(documents)} Word files: archives valid; "
        f"{figure_count} figures described; {decorative_count} icons decorative; "
        f"{table_count} body tables have marked header rows."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
