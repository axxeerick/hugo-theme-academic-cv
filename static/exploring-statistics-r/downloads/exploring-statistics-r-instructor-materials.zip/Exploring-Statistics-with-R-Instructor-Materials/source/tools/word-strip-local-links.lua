-- Keep internal workbook navigation in HTML, but remove nonportable local
-- hyperlinks from Word documents. External web links remain clickable.

local function is_local_workbook_link(target)
  if target:match("^file://") then
    return true
  end

  if target:match("^#") then
    return false
  end

  if not target:match("^%a[%w+.-]*:") then
    return true
  end

  return false
end

function Link(link)
  if FORMAT:match("docx") and is_local_workbook_link(link.target) then
    return link.content
  end
end
