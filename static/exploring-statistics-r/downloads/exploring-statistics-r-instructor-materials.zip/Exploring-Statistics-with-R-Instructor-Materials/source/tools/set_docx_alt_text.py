"""Apply authored figure alt text to a rendered Word document."""

from pathlib import Path
import re
import shutil
import tempfile
import zipfile

from lxml import etree


WP_NS = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
PIC_NS = "http://schemas.openxmlformats.org/drawingml/2006/picture"
ADEC_NS = "http://schemas.microsoft.com/office/drawing/2017/decorative"
DECORATIVE_URI = "{C183D7F6-B498-43B3-948B-1728B52AA6E4}"


def figure_alt_text(source_path):
    text = Path(source_path).read_text(encoding="utf-8")
    chunk_options = re.findall(
        r"""^\s*#\|\s*fig-alt:\s*(?:"([^"]+)"|'([^']+)'|(.+?))\s*$""",
        text,
        flags=re.MULTILINE,
    )
    descriptions = [next(value for value in match if value) for match in chunk_options]
    descriptions.extend(re.findall(r'fig-alt="([^"]+)"', text))
    return descriptions


def mark_decorative(doc_properties):
    doc_properties.set("descr", "")
    extension_list = etree.SubElement(
        doc_properties,
        etree.QName(A_NS, "extLst"),
    )
    extension = etree.SubElement(
        extension_list,
        etree.QName(A_NS, "ext"),
        uri=DECORATIVE_URI,
    )
    etree.SubElement(
        extension,
        etree.QName(ADEC_NS, "decorative"),
        val="1",
    )


def set_docx_alt_text(docx_path, source_path):
    docx_path = Path(docx_path)
    alt_text = figure_alt_text(source_path)

    with zipfile.ZipFile(docx_path, "r") as archive:
        document_xml = archive.read("word/document.xml")
        root = etree.fromstring(document_xml)
        drawings = root.xpath(
            "//w:drawing",
            namespaces={"w": W_NS},
        )

        figure_properties = []
        for drawing in drawings:
            doc_properties = drawing.xpath(
                ".//wp:docPr",
                namespaces={"wp": WP_NS},
            )[0]
            picture_properties = drawing.xpath(
                ".//pic:cNvPr",
                namespaces={"pic": PIC_NS},
            )[0]
            description = (
                picture_properties.get("descr", "")
                or doc_properties.get("descr", "")
            )
            if "/quarto/share/formats/docx/" in description:
                picture_properties.set("descr", "")
                mark_decorative(doc_properties)
            elif description:
                figure_properties.append(
                    (doc_properties, picture_properties)
                )

        if len(figure_properties) != len(alt_text):
            raise RuntimeError(
                f"{source_path}: found {len(figure_properties)} figures "
                f"but {len(alt_text)} authored alt descriptions"
            )

        for items, description in zip(figure_properties, alt_text):
            for item in items:
                item.set("descr", description)

        updated_xml = etree.tostring(
            root,
            xml_declaration=True,
            encoding="UTF-8",
            standalone=True,
        )

        with tempfile.NamedTemporaryFile(
            suffix=".docx",
            dir=docx_path.parent,
            delete=False,
        ) as temporary_file:
            temporary_path = Path(temporary_file.name)

        with zipfile.ZipFile(temporary_path, "w") as destination:
            for entry in archive.infolist():
                contents = (
                    updated_xml
                    if entry.filename == "word/document.xml"
                    else archive.read(entry.filename)
                )
                destination.writestr(entry, contents)

    shutil.move(temporary_path, docx_path)
