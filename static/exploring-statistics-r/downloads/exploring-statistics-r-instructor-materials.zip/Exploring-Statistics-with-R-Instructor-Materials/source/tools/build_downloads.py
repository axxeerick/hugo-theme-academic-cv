#!/usr/bin/env python3
"""Build the student starter ZIP and complete instructor materials archive."""

from __future__ import annotations

from pathlib import Path
import shutil
import zipfile


ROOT = Path(__file__).resolve().parents[1]
DOWNLOADS = ROOT / "downloads"
STARTER_SOURCE = DOWNLOADS / "starter"
STARTER_ZIP = DOWNLOADS / "esr-starter.zip"
PACKAGE_PARENT = ROOT / "output" / "instructor-package"
PACKAGE_NAME = "Exploring-Statistics-with-R-Instructor-Materials"
PACKAGE = PACKAGE_PARENT / PACKAGE_NAME
PACKAGE_ZIP = DOWNLOADS / "exploring-statistics-r-instructor-materials.zip"
COMPLETE_PDF = (
    ROOT
    / "output"
    / "pdf"
    / "Exploring-Statistics-with-R-Complete-Collection.pdf"
)

SOURCE_FILES = (
    "README.md",
    "_quarto.yml",
    "word-format.yml",
    "styles.scss",
    "netlify.toml",
    "exploring-statistics-r.Rproj",
    "index.qmd",
)
SOURCE_DIRS = (
    "R",
    "assets",
    "chapters",
    "data",
    "filters",
    "instructor",
    "reference",
    "scripts",
    "start",
    "tools",
    "downloads/starter",
)
EXCLUDED_NAMES = {
    ".DS_Store",
    ".Rhistory",
    ".RData",
    ".quarto",
    "_freeze",
    "__pycache__",
}


def allowed(path: Path) -> bool:
    return not any(part in EXCLUDED_NAMES or part.startswith("~$") for part in path.parts)


def add_tree(archive: zipfile.ZipFile, source: Path, archive_root: str) -> None:
    for path in sorted(source.rglob("*")):
        if path.is_file() and allowed(path.relative_to(source)):
            relative = path.relative_to(source)
            archive.write(path, Path(archive_root) / relative)


def build_starter_zip() -> None:
    STARTER_ZIP.parent.mkdir(parents=True, exist_ok=True)
    STARTER_ZIP.unlink(missing_ok=True)
    with zipfile.ZipFile(STARTER_ZIP, "w", zipfile.ZIP_DEFLATED) as archive:
        add_tree(archive, STARTER_SOURCE, "exploring-statistics-r-starter")


def copy_tree(source: Path, destination: Path) -> None:
    shutil.copytree(
        source,
        destination,
        ignore=shutil.ignore_patterns(
            ".DS_Store",
            ".Rhistory",
            ".RData",
            ".quarto",
            "_freeze",
            "__pycache__",
            "~$*",
        ),
    )


def build_instructor_folder() -> None:
    # A standalone Word render from inside a website project can leave a copy of
    # the generated output directory in the site. It is build debris, not a site
    # resource, and would otherwise make the instructor archive recursive.
    stale_site_output = ROOT / "_site" / "output"
    if stale_site_output.exists():
        shutil.rmtree(stale_site_output)

    if PACKAGE_PARENT.exists():
        shutil.rmtree(PACKAGE_PARENT)
    PACKAGE.mkdir(parents=True)
    shutil.copy2(
        ROOT / "assets" / "instructor-package-README.md",
        PACKAGE / "README.md",
    )

    source_output = PACKAGE / "source"
    source_output.mkdir()
    for relative in SOURCE_FILES:
        shutil.copy2(ROOT / relative, source_output / Path(relative).name)
    for relative in SOURCE_DIRS:
        destination = source_output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        copy_tree(ROOT / relative, destination)
    (source_output / "downloads").mkdir(exist_ok=True)
    shutil.copy2(STARTER_ZIP, source_output / "downloads" / STARTER_ZIP.name)

    copy_tree(ROOT / "_site", PACKAGE / "website")
    recursive_download = (
        PACKAGE
        / "website"
        / "downloads"
        / "exploring-statistics-r-instructor-materials.zip"
    )
    recursive_download.unlink(missing_ok=True)

    copy_tree(ROOT / "output" / "word", PACKAGE / "word")
    copy_tree(ROOT / "output" / "pdf", PACKAGE / "pdf")
    (PACKAGE / "student-starter").mkdir()
    shutil.copy2(STARTER_ZIP, PACKAGE / "student-starter" / STARTER_ZIP.name)


def build_instructor_zip() -> None:
    PACKAGE_ZIP.unlink(missing_ok=True)
    with zipfile.ZipFile(PACKAGE_ZIP, "w", zipfile.ZIP_DEFLATED) as archive:
        add_tree(archive, PACKAGE, PACKAGE_NAME)


def verify_zip(path: Path) -> None:
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"{path.name} contains a corrupt entry: {bad}")


def main() -> None:
    build_starter_zip()

    required = (
        ROOT / "_site" / "index.html",
        ROOT / "output" / "word",
        COMPLETE_PDF,
    )
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Render the website, Word files, and PDF first. Missing:\n"
            + "\n".join(missing)
        )

    site_downloads = ROOT / "_site" / "downloads"
    site_downloads.mkdir(parents=True, exist_ok=True)
    shutil.copy2(STARTER_ZIP, site_downloads / STARTER_ZIP.name)
    shutil.copy2(COMPLETE_PDF, site_downloads / COMPLETE_PDF.name)

    build_instructor_folder()
    build_instructor_zip()
    verify_zip(STARTER_ZIP)
    verify_zip(PACKAGE_ZIP)
    shutil.copy2(PACKAGE_ZIP, site_downloads / PACKAGE_ZIP.name)

    print(f"Student starter: {STARTER_ZIP} ({STARTER_ZIP.stat().st_size / 1_048_576:.1f} MB)")
    print(f"Instructor folder: {PACKAGE}")
    print(f"Instructor archive: {PACKAGE_ZIP} ({PACKAGE_ZIP.stat().st_size / 1_048_576:.1f} MB)")


if __name__ == "__main__":
    main()
