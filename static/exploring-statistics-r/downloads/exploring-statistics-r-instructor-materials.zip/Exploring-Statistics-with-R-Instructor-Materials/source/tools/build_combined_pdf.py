#!/usr/bin/env python3
"""Build one structured, tagged PDF from the complete Quarto collection."""

from __future__ import annotations

from pathlib import Path
import re
import shutil
import subprocess

from set_docx_alt_text import set_docx_alt_text
from render_word import finalize_document


ROOT = Path(__file__).resolve().parents[1]
QUARTO = shutil.which("quarto")
if QUARTO is None:
    bundled = Path("/Applications/RStudio.app/Contents/Resources/app/quarto/bin/quarto")
    if bundled.exists():
        QUARTO = str(bundled)
    else:
        raise RuntimeError("Quarto was not found.")
SOFFICE = shutil.which("soffice") or shutil.which("libreoffice")

PDF_OUTPUT = ROOT / "output" / "pdf"
PDF_NAME = "Exploring-Statistics-with-R-Complete-Collection.pdf"
PDF = PDF_OUTPUT / PDF_NAME
DOWNLOAD = ROOT / "downloads" / PDF_NAME
COMBINED_DOCX = (
    ROOT / "output" / "word" / "Exploring-Statistics-with-R-Complete-Collection.docx"
)
RENDERED_DOCX = ROOT / COMBINED_DOCX.name
BUILD_QMD = ROOT / "complete-collection-build.qmd"
BUILD_METADATA = ROOT / "complete-collection-word-format.yml"

DOCUMENTS = [
    ("Instructor Guide", "instructor/instructor-guide.qmd"),
    ("Choose Your Path", "start/00-choose-your-path.qmd"),
    ("Set Up RStudio", "start/01-set-up-rstudio.qmd"),
    ("Run Your First Script", "start/02-run-your-first-script.qmd"),
    ("Understanding EAMMi2", "data/codebook.qmd"),
    ("Chapter 1: Introduction", "chapters/01-introduction.qmd"),
    ("Chapter 2: Exploring Data", "chapters/02-exploring-data.qmd"),
    (
        "Chapters 3 and 4: Central Tendency and Variability",
        "chapters/03-04-central-tendency-variability.qmd",
    ),
    (
        "Chapter 5: Other Descriptive Statistics",
        "chapters/05-other-descriptive-statistics.qmd",
    ),
    ("Chapter 6: Correlation and Regression", "chapters/06-correlation-regression.qmd"),
    ("Chapter 9: One-Sample Designs", "chapters/09-one-sample-designs.qmd"),
    ("Chapter 10: Two-Sample Designs", "chapters/10-two-sample-designs.qmd"),
    ("Chapter 11: Analysis of Variance", "chapters/11-independent-anova.qmd"),
    ("Chapter 12: Analysis of Variance", "chapters/12-repeated-anova.qmd"),
    (
        "Chapter 13: Two-Way Independent Analysis of Variance",
        "chapters/13-two-way-anova.qmd",
    ),
    ("Chapter 14: Chi-Square Tests", "chapters/14-chi-square.qmd"),
    ("Chapter 15: Nonparametric Statistics", "chapters/15-nonparametric-statistics.qmd"),
    ("R Command Index", "reference/r-command-index.qmd"),
    ("Troubleshooting", "reference/troubleshooting.qmd"),
    ("Statistical Language", "reference/statistical-language.qmd"),
]

PAGE_BREAK = """```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```"""


def without_front_matter(text: str) -> str:
    if not text.startswith("---"):
        return text
    match = re.match(r"^---\s*\n.*?\n---\s*\n", text, flags=re.DOTALL)
    if match is None:
        raise ValueError("Could not parse Quarto front matter.")
    return text[match.end():]


def normalize_paths(text: str) -> str:
    """Resolve the only source image path from the root build document."""
    return text.replace(
        "](../assets/images/rstudio-panes-labeled.jpeg)",
        "](assets/images/rstudio-panes-labeled.jpeg)",
    )


def anchor_for(title: str) -> str:
    anchor = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
    return f"section-{anchor}"


def build_source() -> None:
    sections: list[str] = []
    for title, relative in DOCUMENTS:
        source = ROOT / relative
        body = normalize_paths(without_front_matter(source.read_text(encoding="utf-8")))
        sections.append(f"# {title} {{#{anchor_for(title)}}}\n\n{body.strip()}")

    contents = "\n".join(
        f"- [{title}](#{anchor_for(title)})" for title, _ in DOCUMENTS
    )

    front_matter = """---
title: "Exploring Statistics with R"
subtitle: "An R workbook to accompany Exploring Statistics: Tales of Distributions"
author: "Erick Axxe"
author-meta: "Erick Axxe"
description: "The complete Exploring Statistics with R collection."
---
"""
    BUILD_QMD.write_text(
        (
            front_matter
            + PAGE_BREAK
            + "\n\n# Contents\n\n"
            + contents
            + "\n\n"
            + PAGE_BREAK
            + "\n\n"
            + ("\n\n" + PAGE_BREAK + "\n\n").join(sections)
            + "\n"
        ),
        encoding="utf-8",
    )
    BUILD_METADATA.write_text(
        """format:
  docx:
    reference-doc: assets/word-reference.docx
    number-sections: false
    highlight-style: github

filters:
  - tools/word-strip-local-links.lua

execute:
  echo: true
  warning: false
  message: false
  freeze: false
""",
        encoding="utf-8",
    )


def main() -> None:
    if SOFFICE is None:
        raise RuntimeError("LibreOffice is required to create the combined PDF.")

    PDF_OUTPUT.mkdir(parents=True, exist_ok=True)
    COMBINED_DOCX.parent.mkdir(parents=True, exist_ok=True)
    DOWNLOAD.parent.mkdir(parents=True, exist_ok=True)
    build_source()

    try:
        subprocess.run(
            [
                QUARTO,
                "render",
                BUILD_QMD.name,
                "--to",
                "docx",
                "--metadata-file",
                BUILD_METADATA.name,
                "--output",
                RENDERED_DOCX.name,
            ],
            cwd=ROOT,
            check=True,
        )
        COMBINED_DOCX.parent.mkdir(parents=True, exist_ok=True)
        RENDERED_DOCX.replace(COMBINED_DOCX)
        generated = COMBINED_DOCX
        set_docx_alt_text(generated, BUILD_QMD)
        finalize_document(generated, BUILD_QMD)

        subprocess.run(
            [
                SOFFICE,
                "--headless",
                "--convert-to",
                "pdf:writer_pdf_Export",
                "--outdir",
                str(PDF_OUTPUT),
                str(generated),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        converted = PDF_OUTPUT / generated.with_suffix(".pdf").name
        if converted != PDF:
            converted.replace(PDF)
        shutil.copy2(PDF, DOWNLOAD)
    finally:
        BUILD_QMD.unlink(missing_ok=True)
        BUILD_METADATA.unlink(missing_ok=True)
        RENDERED_DOCX.unlink(missing_ok=True)

    print(f"Created {COMBINED_DOCX}")
    print(f"Created {PDF}")
    print(f"Copied download to {DOWNLOAD}")


if __name__ == "__main__":
    main()
