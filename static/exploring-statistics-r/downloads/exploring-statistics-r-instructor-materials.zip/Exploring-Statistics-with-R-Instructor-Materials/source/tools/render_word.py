"""Render the complete set of reviewable Word documents."""

from pathlib import Path
import re
import shutil
import subprocess

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from set_docx_alt_text import set_docx_alt_text


ROOT = Path(__file__).resolve().parents[1]
QUARTO = shutil.which("quarto")
if QUARTO is None:
    rstudio_quarto = Path(
        "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/quarto"
    )
    if rstudio_quarto.exists():
        QUARTO = str(rstudio_quarto)
    else:
        raise RuntimeError(
            "Quarto was not found. Install Quarto or add it to your system PATH."
        )
OUTPUT = ROOT / "output" / "word"

DOCUMENTS = {
    "start": [
        "start/00-choose-your-path.qmd",
        "start/01-set-up-rstudio.qmd",
        "start/02-run-your-first-script.qmd",
        "data/codebook.qmd",
    ],
    "chapters": [
        "chapters/01-introduction.qmd",
        "chapters/02-exploring-data.qmd",
        "chapters/03-04-central-tendency-variability.qmd",
        "chapters/05-other-descriptive-statistics.qmd",
        "chapters/06-correlation-regression.qmd",
        "chapters/09-one-sample-designs.qmd",
        "chapters/10-two-sample-designs.qmd",
        "chapters/11-independent-anova.qmd",
        "chapters/12-repeated-anova.qmd",
        "chapters/13-two-way-anova.qmd",
        "chapters/14-chi-square.qmd",
        "chapters/15-nonparametric-statistics.qmd",
    ],
    "reference": [
        "reference/r-command-index.qmd",
        "reference/troubleshooting.qmd",
        "reference/statistical-language.qmd",
    ],
    "instructor": ["instructor/instructor-guide.qmd"],
}


def source_title(source: Path) -> str:
    text = source.read_text(encoding="utf-8")
    match = re.search(r'^title:\s*["\']?(.+?)["\']?\s*$', text, re.MULTILINE)
    return match.group(1) if match else source.stem.replace("-", " ").title()


def mark_table_headers(document: Document) -> None:
    """Repeat and identify the first row of each body table as a header row."""
    for table in document.tables:
        if not table.rows:
            continue
        row_properties = table.rows[0]._tr.get_or_add_trPr()
        table_header = row_properties.find(qn("w:tblHeader"))
        if table_header is None:
            table_header = OxmlElement("w:tblHeader")
            row_properties.append(table_header)
        table_header.set(qn("w:val"), "true")


def finalize_document(path: Path, source: Path) -> None:
    document = Document(path)
    properties = document.core_properties
    properties.author = "Erick Axxe"
    properties.last_modified_by = "Erick Axxe"
    properties.title = source_title(source)
    properties.subject = (
        "Exploring Statistics with R: an R workbook to accompany "
        "Exploring Statistics: Tales of Distributions"
    )
    properties.keywords = "R, RStudio, statistics, EAMMi2, workbook"
    mark_table_headers(document)
    document.save(path)


def main():
    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    OUTPUT.mkdir(parents=True)

    for group, files in DOCUMENTS.items():
        group_output = OUTPUT / group
        group_output.mkdir(parents=True)
        for source in files:
            subprocess.run(
                [
                    QUARTO,
                    "render",
                    source,
                    "--to",
                    "docx",
                    "--metadata-file",
                    "word-format.yml",
                    "--output-dir",
                    str(group_output),
                ],
                cwd=ROOT,
                check=True,
            )
            generated = group_output / Path(source).with_suffix(".docx")
            target = group_output / Path(source).with_suffix(".docx").name
            shutil.move(generated, target)
            set_docx_alt_text(target, ROOT / source)
            finalize_document(target, ROOT / source)

        for child in group_output.iterdir():
            if child.is_dir():
                shutil.rmtree(child)
            elif child.suffix.lower() != ".docx":
                child.unlink()

    print(f"Rendered {sum(map(len, DOCUMENTS.values()))} Word documents.")


if __name__ == "__main__":
    main()
