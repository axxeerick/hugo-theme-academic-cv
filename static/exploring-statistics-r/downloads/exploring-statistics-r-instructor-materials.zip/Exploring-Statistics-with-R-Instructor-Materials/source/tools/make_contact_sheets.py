#!/usr/bin/env python3
"""Create compact contact sheets from rendered Word-document pages."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw


def make_sheet(source: Path, destination: Path) -> None:
    pages = sorted(
        source.glob("page-*.png"),
        key=lambda path: int(path.stem.split("-")[-1]),
    )
    if not pages:
        return

    columns = 4
    thumb_width = 300
    margin = 16
    label_height = 24
    thumbnails = []

    for page in pages:
        image = Image.open(page).convert("RGB")
        height = round(image.height * thumb_width / image.width)
        thumbnails.append(image.resize((thumb_width, height)))

    cell_height = max(image.height for image in thumbnails) + label_height
    rows = (len(thumbnails) + columns - 1) // columns
    sheet = Image.new(
        "RGB",
        (
            columns * thumb_width + (columns + 1) * margin,
            rows * cell_height + (rows + 1) * margin,
        ),
        "white",
    )
    draw = ImageDraw.Draw(sheet)

    for index, image in enumerate(thumbnails):
        row, column = divmod(index, columns)
        x = margin + column * (thumb_width + margin)
        y = margin + row * (cell_height + margin)
        draw.text((x, y), f"Page {index + 1}", fill="black")
        sheet.paste(image, (x, y + label_height))

    destination.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(destination)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    arguments = parser.parse_args()

    for document in sorted(path for path in arguments.source.iterdir() if path.is_dir()):
        make_sheet(document, arguments.destination / f"{document.name}.png")


if __name__ == "__main__":
    main()
