"""Create the Pandoc reference document used for workbook Word editions."""

from pathlib import Path
import subprocess

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import (
    WD_LINE_SPACING,
    WD_TAB_ALIGNMENT,
)
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
PANDOC = Path(
    "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/tools/"
    "aarch64/pandoc"
)
OUTPUT = ROOT / "assets" / "word-reference.docx"

NAVY = RGBColor(40, 83, 107)
DARK = RGBColor(40, 40, 40)
GRAY = RGBColor(90, 90, 90)
LIGHT_BLUE = "EAF2F6"


def set_cell_shading(cell, fill):
    properties = cell._tc.get_or_add_tcPr()
    shading = properties.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        properties.append(shading)
    shading.set(qn("w:fill"), fill)


def add_page_field(paragraph):
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instruction = OxmlElement("w:instrText")
    instruction.set(qn("xml:space"), "preserve")
    instruction.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instruction, separate, end])


def style_text(style, font_name, size, color=DARK, bold=None, italic=None):
    style.font.name = font_name
    style.font.size = Pt(size)
    style.font.color.rgb = color
    if bold is not None:
        style.font.bold = bold
    if italic is not None:
        style.font.italic = italic


def set_keep_with_next(style):
    paragraph_properties = style.element.get_or_add_pPr()
    keep_next = paragraph_properties.find(qn("w:keepNext"))
    if keep_next is None:
        keep_next = OxmlElement("w:keepNext")
        paragraph_properties.append(keep_next)


def main():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open("wb") as destination:
        subprocess.run(
            [str(PANDOC), "--print-default-data-file", "reference.docx"],
            check=True,
            stdout=destination,
        )

    document = Document(OUTPUT)
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.78)
    section.bottom_margin = Inches(0.72)
    section.left_margin = Inches(0.82)
    section.right_margin = Inches(0.82)
    section.header_distance = Inches(0.3)
    section.footer_distance = Inches(0.35)

    properties = document.core_properties
    properties.author = "Erick Axxe"
    properties.last_modified_by = "Erick Axxe"
    properties.title = "Exploring Statistics with R"
    properties.subject = (
        "An R workbook to accompany Exploring Statistics: Tales of Distributions"
    )
    properties.keywords = "R, RStudio, statistics, EAMMi2, workbook"

    normal = document.styles["Normal"]
    style_text(normal, "Calibri", 10.5)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    normal.paragraph_format.line_spacing = 1.18

    title = document.styles["Title"]
    style_text(title, "Calibri", 24, NAVY, bold=True)
    title.paragraph_format.space_after = Pt(7)

    subtitle = document.styles["Subtitle"]
    style_text(subtitle, "Calibri", 12.5, GRAY, italic=True)
    subtitle.paragraph_format.space_after = Pt(12)

    heading_specs = {
        "Heading 1": (16, 13, 5),
        "Heading 2": (13.5, 11, 4),
        "Heading 3": (11.5, 8, 3),
        "Heading 4": (10.5, 7, 2),
    }
    for style_name, (size, before, after) in heading_specs.items():
        style = document.styles[style_name]
        style_text(style, "Calibri", size, NAVY, bold=True)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        set_keep_with_next(style)

    for style_name in ("Source Code", "Verbatim Char"):
        if style_name in document.styles:
            style = document.styles[style_name]
            style_text(style, "Consolas", 8.5, DARK)
            if hasattr(style, "paragraph_format"):
                style.paragraph_format.space_after = Pt(4)
                style.paragraph_format.line_spacing = 1.0

    for style_name in ("Caption", "Table Caption"):
        if style_name in document.styles:
            style = document.styles[style_name]
            style_text(style, "Calibri", 9, GRAY, italic=True)
            style.paragraph_format.space_before = Pt(3)
            style.paragraph_format.space_after = Pt(6)

    if "Block Text" in document.styles:
        block_text = document.styles["Block Text"]
        style_text(block_text, "Calibri", 10, DARK)
        block_text.paragraph_format.left_indent = Inches(0.22)
        block_text.paragraph_format.right_indent = Inches(0.12)
        block_text.paragraph_format.space_before = Pt(4)
        block_text.paragraph_format.space_after = Pt(6)

    header = section.header
    header_paragraph = header.paragraphs[0]
    header_paragraph.paragraph_format.space_after = Pt(0)
    header_paragraph.paragraph_format.tab_stops.add_tab_stop(
        Inches(6.86),
        WD_TAB_ALIGNMENT.RIGHT,
    )
    header_paragraph.add_run(
        "Exploring Statistics: Tales of Distributions"
    )
    header_paragraph.add_run("\t")
    header_paragraph.add_run("Erick Axxe")
    for run in header_paragraph.runs:
        run.font.name = "Calibri"
        run.font.size = Pt(8)
        run.font.color.rgb = GRAY

    footer = section.footer
    footer_paragraph = footer.paragraphs[0]
    footer_paragraph.paragraph_format.space_after = Pt(0)
    footer_paragraph.paragraph_format.tab_stops.add_tab_stop(
        Inches(6.86),
        WD_TAB_ALIGNMENT.RIGHT,
    )
    footer_paragraph.add_run("Exploring Statistics with R")
    footer_paragraph.add_run("\tPage ")
    add_page_field(footer_paragraph)
    for run in footer_paragraph.runs:
        run.font.name = "Calibri"
        run.font.size = Pt(8)
        run.font.color.rgb = GRAY

    document.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
