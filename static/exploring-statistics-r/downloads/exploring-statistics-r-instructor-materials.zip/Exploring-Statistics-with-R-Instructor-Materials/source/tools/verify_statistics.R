# Verify the key data decisions and statistical results used in the workbook.

close_enough <- function(actual, expected, tolerance = 1e-5) {
  isTRUE(all.equal(
    as.numeric(actual),
    as.numeric(expected),
    tolerance = tolerance
  ))
}

run_script <- function(path) {
  invisible(capture.output(source(path, local = globalenv())))
}

pdf(NULL)
on.exit(dev.off(), add = TRUE)

run_script("scripts/01-introduction.R")
stopifnot(identical(dim(eammi), c(2073L, 39L)))
stopifnot(identical(as.integer(gender_summary$Frequency), c(30L, 1524L, 519L)))

run_script("scripts/02-frequency-distributions.R")
stopifnot(sum(eammi$SWLS == 0, na.rm = TRUE) == 1)
stopifnot(nrow(swls_table) == 32)
stopifnot(sum(swls_table$Frequency) == 2073)

run_script("scripts/03-04-central-tendency-variability.R")
stopifnot(sum(eammi$IMPcareer == 180, na.rm = TRUE) == 1)
stopifnot(identical(as.integer(career_summary$N), c(830L, 654L, 565L)))
stopifnot(
  close_enough(career_summary$Mean, c(37.02289, 35.12359, 37.66752))
)

run_script("scripts/05-other-descriptive-statistics.R")
stopifnot(stress_summary$N == 2071)
stopifnot(stress_filtered_summary$N == 2032)
stopifnot(close_enough(stress_disability_d$CohensD, 0.2052646))

run_script("scripts/06-correlation-regression.R")
stopifnot(close_enough(support_correlations["Stress", "SupportFamily"], -0.03098761))
stopifnot(close_enough(support_correlations["Stress", "SupportFriends"], 0.01778431))
stopifnot(close_enough(support_correlations["Stress", "SupportSpecial"], 0.08823717))

run_script("scripts/09-one-sample-designs.R")
stopifnot(duration_filtered_summary$N == 1814)
stopifnot(close_enough(duration_final_test$statistic, -5.8678, 1e-4))
stopifnot(close_enough(duration_d, -0.1377695))

run_script("scripts/10-two-sample-designs.R")
stopifnot(identical(as.integer(belonging_summary$N), c(897L, 438L)))
stopifnot(close_enough(belonging_t_test$statistic, -4.6974, 1e-4))
stopifnot(close_enough(belonging_d$CohensD, -0.2739, 1e-3))

run_script("scripts/11-anova-independent.R")
moa_anova_table <- summary(moa_adult_anova)[[1]]
stopifnot(close_enough(moa_anova_table["Adult", "F value"], 63.3, 1e-3))
stopifnot(close_enough(moa_eta_squared, 0.06000782))

run_script("scripts/12-anova-repeated.R")
social_media_anova_table <- summary(social_media_anova)[[1]]
stopifnot(
  close_enough(social_media_anova_table["Reason", "F value"], 115.444, 1e-3)
)
stopifnot(close_enough(social_media_eta_squared, 0.05280006))
stopifnot(close_enough(support_pairwise$p[3], 0.0588, 1e-3))

run_script("scripts/13-two-way-anova.R")
swls_interaction <- swls_anova_table |>
  dplyr::filter(Effect == "PoliticsDichotomous:Adult")
stopifnot(close_enough(swls_interaction$p, 0.7871763))
stopifnot(swls_interaction$p > 0.05)

run_script("scripts/14-chi-square.R")
stopifnot(identical(as.integer(party_counts), c(1051L, 484L)))
stopifnot(identical(as.integer(politics_counts), c(897L, 438L)))
stopifnot(close_enough(party_chi$statistic, 209.44, 1e-3))
stopifnot(close_enough(politics_chi$statistic, 157.81, 1e-3))

run_script("scripts/15-nonparametric-statistics.R")
stopifnot(close_enough(hobbies_party_test$statistic, 269788, 1e-6))
stopifnot(close_enough(career_hobby_test$statistic, 1015505, 1e-6))
stopifnot(close_enough(hobbies_adult_test$p.value, 0.0118, 1e-3))
stopifnot(close_enough(hobbies_swls_test$estimate, -0.09315736))

message("All publication statistics checks passed.")
