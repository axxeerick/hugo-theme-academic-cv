# Build the student-facing R scripts from executable chapter code.
# Run from the project root with: Rscript tools/sync-chapter-scripts.R

chapter_scripts <- c(
  "chapters/01-introduction.qmd" = "01-introduction.R",
  "chapters/02-exploring-data.qmd" = "02-frequency-distributions.R",
  "chapters/03-04-central-tendency-variability.qmd" =
    "03-04-central-tendency-variability.R",
  "chapters/05-other-descriptive-statistics.qmd" =
    "05-other-descriptive-statistics.R",
  "chapters/06-correlation-regression.qmd" = "06-correlation-regression.R",
  "chapters/09-one-sample-designs.qmd" = "09-one-sample-designs.R",
  "chapters/10-two-sample-designs.qmd" = "10-two-sample-designs.R",
  "chapters/11-independent-anova.qmd" = "11-anova-independent.R",
  "chapters/12-repeated-anova.qmd" = "12-anova-repeated.R",
  "chapters/13-two-way-anova.qmd" = "13-two-way-anova.R",
  "chapters/14-chi-square.qmd" = "14-chi-square.R",
  "chapters/15-nonparametric-statistics.qmd" =
    "15-nonparametric-statistics.R"
)

title_from_yaml <- function(lines) {
  title_line <- grep("^title:", lines, value = TRUE)[1]
  trimws(gsub('^title:[[:space:]]*"?|"$', "", title_line))
}

script_from_qmd <- function(source_file) {
  lines <- readLines(source_file, warn = FALSE)
  output <- c(
    paste0("# Exploring Statistics with R: ", title_from_yaml(lines)),
    "# Run one complete expression at a time as you work through the chapter.",
    ""
  )

  heading <- "Chapter setup"
  last_written_heading <- ""
  in_chunk <- FALSE
  chunk_lines <- character()
  pending_script_comments <- character()

  for (line in lines) {
    if (!in_chunk && grepl("^<!--[[:space:]]*script-comment:", line)) {
      script_comment <- sub(
        "^<!--[[:space:]]*script-comment:[[:space:]]*",
        "",
        line
      )
      script_comment <- sub("[[:space:]]*-->[[:space:]]*$", "", script_comment)
      pending_script_comments <- c(pending_script_comments, script_comment)
      next
    }

    if (!in_chunk && grepl("^#{2,4}[[:space:]]", line)) {
      heading <- sub("^#{2,4}[[:space:]]+", "", line)
      next
    }

    if (!in_chunk && grepl("^```(\\{r|r[[:space:]]*$)", line)) {
      in_chunk <- TRUE
      chunk_lines <- character()
      next
    }

    if (in_chunk && line == "```") {
      in_chunk <- FALSE

      if (any(grepl("^#\\|[[:space:]]*include:[[:space:]]*false", chunk_lines))) {
        pending_script_comments <- character()
        next
      }

      figure_caption <- sub(
        "^#\\|[[:space:]]*fig-cap:[[:space:]]*",
        "",
        grep("^#\\|[[:space:]]*fig-cap:", chunk_lines, value = TRUE)
      )
      figure_caption <- sub('^"', "", figure_caption)
      figure_caption <- sub('"$', "", figure_caption)
      code <- chunk_lines[!grepl("^#\\|", chunk_lines)]

      while (length(code) > 0 && trimws(code[1]) == "") {
        code <- code[-1]
      }
      while (length(code) > 0 && trimws(code[length(code)]) == "") {
        code <- code[-length(code)]
      }
      if (length(code) == 0) {
        pending_script_comments <- character()
        next
      }

      if (!identical(heading, last_written_heading)) {
        output <- c(output, paste0("# ---- ", heading, " ----"), "")
        last_written_heading <- heading
      }
      if (length(pending_script_comments) > 0) {
        output <- c(
          output,
          paste0("# ", pending_script_comments),
          ""
        )
        pending_script_comments <- character()
      }
      if (length(figure_caption) > 0) {
        output <- c(output, paste0("# Figure: ", figure_caption), "")
      }
      output <- c(output, code, "")
      next
    }

    if (in_chunk) {
      chunk_lines <- c(chunk_lines, line)
    }
  }

  output
}

dir.create("scripts", showWarnings = FALSE)
dir.create("downloads/starter/scripts", recursive = TRUE, showWarnings = FALSE)

for (source_file in names(chapter_scripts)) {
  script_name <- unname(chapter_scripts[[source_file]])
  script_lines <- script_from_qmd(source_file)

  writeLines(script_lines, file.path("scripts", script_name), useBytes = TRUE)
  writeLines(
    script_lines,
    file.path("downloads", "starter", "scripts", script_name),
    useBytes = TRUE
  )
}

invisible(file.copy(
  "scripts/_setup.R",
  "downloads/starter/scripts/_setup.R",
  overwrite = TRUE
))
invisible(file.copy(
  "scripts/00-open-and-check-data.R",
  "downloads/starter/scripts/00-open-and-check-data.R",
  overwrite = TRUE
))

message("Synchronized ", length(chapter_scripts), " chapter scripts.")
